// Edge Function: create-payment-intent
//
// ينشئ عملية دفع (PaymentIntent) في Stripe من الخادم. مفتاح Stripe السري
// (STRIPE_SECRET_KEY) يُقرأ فقط من أسرار Supabase (Deno.env)، ولا يظهر أبدًا
// في كود تطبيق Flutter ولا في أي مستودع Git.
//
// الحماية من الاستدعاء العشوائي: هذه الدالة منشورة بخيار verify_jwt=true
// (الافتراضي في Supabase)، أي أن منصة Supabase نفسها ترفض أي طلب لا يحمل
// مفتاح المشروع (anon/publishable key) في الترويسة قبل أن يصل الطلب إلى هذا
// الكود إطلاقًا — لا حاجة لأي تحقق إضافي هنا لهذا الغرض.

import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const STRIPE_SECRET_KEY = Deno.env.get("STRIPE_SECRET_KEY");
const jsonHeaders = { "Content-Type": "application/json" };

Deno.serve(async (req: Request) => {
  if (req.method !== "POST") {
    return new Response(JSON.stringify({ error: "Method not allowed" }), {
      status: 405,
      headers: jsonHeaders,
    });
  }

  if (!STRIPE_SECRET_KEY) {
    return new Response(
      JSON.stringify({ error: "STRIPE_SECRET_KEY is not configured on the server" }),
      { status: 500, headers: jsonHeaders },
    );
  }

  let body: { amount?: unknown; currency?: unknown };
  try {
    body = await req.json();
  } catch {
    return new Response(JSON.stringify({ error: "Invalid JSON body" }), {
      status: 400,
      headers: jsonHeaders,
    });
  }

  // amount بالوحدة الصغرى للعملة (قروش/سنتات) — مثال: 10.50 دولار = 1050
  const amount = Number(body.amount);
  const currency = String(body.currency ?? "usd").toLowerCase();

  if (!Number.isFinite(amount) || amount <= 0) {
    return new Response(JSON.stringify({ error: "Invalid amount" }), {
      status: 400,
      headers: jsonHeaders,
    });
  }

  try {
    const stripeResponse = await fetch("https://api.stripe.com/v1/payment_intents", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${STRIPE_SECRET_KEY}`,
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: new URLSearchParams({
        amount: String(Math.round(amount)),
        currency,
        "automatic_payment_methods[enabled]": "true",
      }),
    });

    const data = await stripeResponse.json();

    if (!stripeResponse.ok) {
      return new Response(
        JSON.stringify({ error: data?.error?.message ?? "Stripe error" }),
        { status: stripeResponse.status, headers: jsonHeaders },
      );
    }

    return new Response(
      JSON.stringify({ clientSecret: data.client_secret, paymentIntentId: data.id }),
      { headers: jsonHeaders },
    );
  } catch {
    return new Response(JSON.stringify({ error: "Unexpected server error" }), {
      status: 500,
      headers: jsonHeaders,
    });
  }
});
