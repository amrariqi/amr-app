import 'dart:convert';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:http/http.dart' as http;
import '../config/backend_config.dart';
import '../models/models.dart';

/// نتيجة عملية دفع — تحتوي فقط على حالة النجاح ورقم مرجعي، ولا تحتوي
/// ولن تحتوي أبدًا على رقم بطاقة أو CVV.
class PaymentResult {
  final bool success;
  final String? reference;
  final String? errorMessage;

  const PaymentResult({
    required this.success,
    this.reference,
    this.errorMessage,
  });
}

abstract class PaymentGateway {
  Future<PaymentResult> charge({required double amount});
}

/// الدفع النقدي يكتمل محليًا وفوريًا — لا حاجة لأي اتصال بالإنترنت.
class CashPaymentGateway implements PaymentGateway {
  @override
  Future<PaymentResult> charge({required double amount}) async {
    return PaymentResult(
      success: true,
      reference: 'CASH-${DateTime.now().millisecondsSinceEpoch}',
    );
  }
}

// =============================================================================
// الدفع بالبطاقة عبر Stripe.
//
// هذا التطبيق لا يرى رقم البطاقة ولا CVV في أي لحظة: الحقول التي يكتب فيها
// الزبون رقم بطاقته هي واجهة PaymentSheet الجاهزة من حزمة flutter_stripe،
// وهي تُرسِل البيانات مباشرة ومشفَّرة إلى خوادم Stripe — لا تمر عبر خادمنا
// ولا عبر هذا التطبيق. كل ما يحدث هنا:
//   1) نطلب من Edge Function الخاصة بنا (على Supabase) إنشاء "عملية دفع"
//      (PaymentIntent)؛ هي وحدها من تحمل مفتاح Stripe السري، ولا يصل هذا
//      المفتاح إلى الهاتف إطلاقًا.
//   2) نعرض PaymentSheet للزبون ليُدخل بطاقته مباشرة إلى Stripe.
//   3) عند النجاح، نحفظ رقم العملية المرجعي فقط (reference) في سجل المبيعات.
//
// راجع supabase/functions/create-payment-intent لكود الخادم، وملف
// lib/config/backend_config.dart لعنوان المشروع ومفاتيحه العامة.
class StripeCardGateway implements PaymentGateway {
  @override
  Future<PaymentResult> charge({required double amount}) async {
    try {
      final amountInSubunits = (amount * 100).round(); // مثال: 10.50 → 1050

      final response = await http.post(
        Uri.parse('${BackendConfig.supabaseProjectUrl}/functions/v1/create-payment-intent'),
        headers: {
          'Content-Type': 'application/json',
          'apikey': BackendConfig.supabaseAnonKey,
          'Authorization': 'Bearer ${BackendConfig.supabaseAnonKey}',
        },
        body: jsonEncode({'amount': amountInSubunits, 'currency': 'usd'}),
      );

      final data = jsonDecode(response.body) as Map<String, dynamic>;

      if (response.statusCode != 200 || data['clientSecret'] == null) {
        return PaymentResult(
          success: false,
          errorMessage: data['error']?.toString() ?? 'تعذّر إنشاء عملية الدفع',
        );
      }

      final clientSecret = data['clientSecret'] as String;
      final paymentIntentId = data['paymentIntentId'] as String?;

      await Stripe.instance.initPaymentSheet(
        paymentSheetParameters: SetupPaymentSheetParameters(
          paymentIntentClientSecret: clientSecret,
          merchantDisplayName: 'نظام نقاط البيع',
        ),
      );

      await Stripe.instance.presentPaymentSheet();

      return PaymentResult(success: true, reference: paymentIntentId ?? clientSecret);
    } on StripeException catch (e) {
      // المستخدم ألغى الدفع أو رفضت البطاقة — ليست حالة خطأ غير متوقعة.
      return PaymentResult(
        success: false,
        errorMessage: e.error.localizedMessage ?? 'تم إلغاء الدفع',
      );
    } catch (e) {
      return PaymentResult(success: false, errorMessage: 'تعذّر إتمام الدفع: $e');
    }
  }
}

/// المحفظة الإلكترونية/التحويل البنكي المحلي يحتاج بوابة الدولة المحدَّدة
/// (راجع الرسالة أدناه) — Stripe لا يغطي هذه الطرق في كل الدول العربية.
class WalletGatewayPending implements PaymentGateway {
  @override
  Future<PaymentResult> charge({required double amount}) async {
    return const PaymentResult(
      success: false,
      errorMessage:
          'الدفع بالمحفظة الإلكترونية/التحويل البنكي يحتاج بوابة محلية إضافية — أخبرني باسم دولتك لأربطها.',
    );
  }
}

PaymentGateway gatewayFor(PaymentMethod method) {
  switch (method) {
    case PaymentMethod.cash:
      return CashPaymentGateway();
    case PaymentMethod.card:
      return StripeCardGateway();
    case PaymentMethod.wallet:
      return WalletGatewayPending();
  }
}
