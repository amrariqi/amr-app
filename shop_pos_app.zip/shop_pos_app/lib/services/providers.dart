import 'package:flutter/foundation.dart';
import '../db/database_helper.dart';
import '../models/models.dart';

class CartLine {
  final Product product;
  int quantity;
  CartLine({required this.product, this.quantity = 1});
  double get lineTotal => product.price * quantity;
}

class CartProvider extends ChangeNotifier {
  final Map<int, CartLine> _lines = {};

  List<CartLine> get lines => _lines.values.toList(growable: false);

  double get total => _lines.values.fold(0.0, (sum, line) => sum + line.lineTotal);

  int get itemCount => _lines.values.fold(0, (sum, line) => sum + line.quantity);

  bool get isEmpty => _lines.isEmpty;

  void addProduct(Product product) {
    final id = product.id;
    if (id == null) return;
    if (_lines.containsKey(id)) {
      _lines[id]!.quantity += 1;
    } else {
      _lines[id] = CartLine(product: product);
    }
    notifyListeners();
  }

  void setQuantity(int productId, int quantity) {
    if (quantity <= 0) {
      _lines.remove(productId);
    } else if (_lines.containsKey(productId)) {
      _lines[productId]!.quantity = quantity;
    }
    notifyListeners();
  }

  void removeProduct(int productId) {
    _lines.remove(productId);
    notifyListeners();
  }

  void clear() {
    _lines.clear();
    notifyListeners();
  }
}

class InventoryProvider extends ChangeNotifier {
  List<Product> _products = [];
  bool _loading = false;

  List<Product> get products => _products;
  bool get loading => _loading;

  Future<void> loadProducts() async {
    _loading = true;
    notifyListeners();
    _products = await DatabaseHelper.instance.getProducts();
    _loading = false;
    notifyListeners();
  }

  Future<void> addProduct(Product product) async {
    await DatabaseHelper.instance.insertProduct(product);
    await loadProducts();
  }

  Future<void> updateProduct(Product product) async {
    await DatabaseHelper.instance.updateProduct(product);
    await loadProducts();
  }

  Future<void> deleteProduct(int id) async {
    await DatabaseHelper.instance.deleteProduct(id);
    await loadProducts();
  }
}
