// النماذج الأساسية: المنتج، طريقة الدفع، عنصر الفاتورة، والفاتورة (البيعة).
//
// ملاحظة مهمة ومقصودة: لا يوجد هنا أي حقل لرقم بطاقة أو تاريخ انتهاء أو CVV،
// ولن يُضاف أبدًا. بيانات البطاقة تُجمع فقط عبر SDK بوابة الدفع المرخّصة نفسها،
// ولا تصل إلى قاعدة بيانات هذا التطبيق مطلقًا — راجع services/payment_gateway.dart.

class Product {
  final int? id;
  final String name;
  final double price;
  final int stockQuantity;
  final String? category;
  final String? barcode;

  const Product({
    this.id,
    required this.name,
    required this.price,
    required this.stockQuantity,
    this.category,
    this.barcode,
  });

  Product copyWith({
    int? id,
    String? name,
    double? price,
    int? stockQuantity,
    String? category,
    String? barcode,
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      price: price ?? this.price,
      stockQuantity: stockQuantity ?? this.stockQuantity,
      category: category ?? this.category,
      barcode: barcode ?? this.barcode,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'price': price,
      'stock_quantity': stockQuantity,
      'category': category,
      'barcode': barcode,
    };
  }

  factory Product.fromMap(Map<String, dynamic> map) {
    return Product(
      id: map['id'] as int?,
      name: map['name'] as String,
      price: (map['price'] as num).toDouble(),
      stockQuantity: map['stock_quantity'] as int,
      category: map['category'] as String?,
      barcode: map['barcode'] as String?,
    );
  }
}

enum PaymentMethod { cash, card, wallet }

extension PaymentMethodX on PaymentMethod {
  String get label {
    switch (this) {
      case PaymentMethod.cash:
        return 'نقدًا';
      case PaymentMethod.card:
        return 'بطاقة';
      case PaymentMethod.wallet:
        return 'محفظة إلكترونية';
    }
  }

  String get storageValue => name;

  static PaymentMethod fromStorage(String value) {
    return PaymentMethod.values.firstWhere(
      (e) => e.name == value,
      orElse: () => PaymentMethod.cash,
    );
  }
}

class SaleItem {
  final int? id;
  final int? saleId;
  final int productId;
  final String productName; // نسخة من اسم المنتج وقت البيع
  final double unitPrice;
  final int quantity;

  const SaleItem({
    this.id,
    this.saleId,
    required this.productId,
    required this.productName,
    required this.unitPrice,
    required this.quantity,
  });

  double get lineTotal => unitPrice * quantity;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'sale_id': saleId,
      'product_id': productId,
      'product_name': productName,
      'unit_price': unitPrice,
      'quantity': quantity,
    };
  }

  factory SaleItem.fromMap(Map<String, dynamic> map) {
    return SaleItem(
      id: map['id'] as int?,
      saleId: map['sale_id'] as int?,
      productId: map['product_id'] as int,
      productName: map['product_name'] as String,
      unitPrice: (map['unit_price'] as num).toDouble(),
      quantity: map['quantity'] as int,
    );
  }
}

class Sale {
  final int? id;
  final DateTime createdAt;
  final double total;
  final PaymentMethod paymentMethod;
  final String? gatewayReference; // رقم مرجعي من بوابة الدفع فقط — أبدًا رقم بطاقة
  final bool synced;
  final List<SaleItem> items;

  const Sale({
    this.id,
    required this.createdAt,
    required this.total,
    required this.paymentMethod,
    this.gatewayReference,
    this.synced = false,
    this.items = const [],
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'created_at': createdAt.toIso8601String(),
      'total': total,
      'payment_method': paymentMethod.storageValue,
      'gateway_reference': gatewayReference,
      'synced': synced ? 1 : 0,
    };
  }

  factory Sale.fromMap(Map<String, dynamic> map, {List<SaleItem> items = const []}) {
    return Sale(
      id: map['id'] as int?,
      createdAt: DateTime.parse(map['created_at'] as String),
      total: (map['total'] as num).toDouble(),
      paymentMethod: PaymentMethodX.fromStorage(map['payment_method'] as String),
      gatewayReference: map['gateway_reference'] as String?,
      synced: (map['synced'] as int) == 1,
      items: items,
    );
  }
}
