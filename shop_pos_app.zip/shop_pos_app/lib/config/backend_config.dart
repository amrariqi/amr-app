/// إعدادات الاتصال بالخادم الخلفي (Supabase Edge Function) وبوابة Stripe.
///
/// كل القيم هنا "عامة بطبيعتها" (Publishable) ومخصَّصة أصلًا لتُضمَّن داخل
/// كود التطبيق — على عكس المفتاح السري (Secret Key) الذي يبقى فقط في أسرار
/// Supabase على الخادم ولا يظهر هنا إطلاقًا. راجع lib/services/payment_gateway.dart.
///
/// هذا المشروع (shop-pos-backend) على Supabase منفصل تمامًا عن مشروع
/// AM Express Logistics — لا تُشارك مفاتيحه ولا مستودع الكود بينهما.
class BackendConfig {
  /// رابط مشروع Supabase الخاص بهذا التطبيق (shop-pos-backend).
  static const String supabaseProjectUrl = 'https://xwduiphblxecsimjchbg.supabase.co';

  /// المفتاح العام (publishable) لمشروع Supabase — آمن لوضعه هنا.
  static const String supabaseAnonKey = 'sb_publishable_QpjoKMPfDG5oywzw_W1sNw_Xm8VHyTU';

  /// المفتاح العام (publishable) لحساب Stripe التجريبي — آمن لوضعه هنا.
  /// عند الانتقال للتشغيل الفعلي، استبدله بمفتاح pk_live_ من حساب Stripe نفسه،
  /// وحدّث STRIPE_SECRET_KEY في أسرار Supabase بمفتاحه السري sk_live_ المقابل.
  static const String stripePublishableKey =
      'pk_test_51UHFm63oqLwDGHUT5lqIoO0JbmCOggT69eNEyGaLhphcYhMPaKuVzbaj0fxhX6o7iI0ubogSpXBD2B3GMFgoBaW00084Ijmk4n';
}
