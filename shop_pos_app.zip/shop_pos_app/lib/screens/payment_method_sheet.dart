import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../db/database_helper.dart';
import '../models/models.dart';
import '../services/payment_gateway.dart';
import '../services/providers.dart';
import '../theme/app_theme.dart';

class PaymentMethodSheet extends StatefulWidget {
  const PaymentMethodSheet({super.key});

  @override
  State<PaymentMethodSheet> createState() => _PaymentMethodSheetState();
}

class _PaymentMethodSheetState extends State<PaymentMethodSheet> {
  bool _processing = false;

  Future<void> _pay(PaymentMethod method) async {
    final cart = context.read<CartProvider>();
    setState(() => _processing = true);

    final gateway = gatewayFor(method);
    final result = await gateway.charge(amount: cart.total);

    if (!mounted) return;

    if (!result.success) {
      setState(() => _processing = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.errorMessage ?? 'تعذّر إتمام الدفع')),
      );
      return;
    }

    final sale = Sale(
      createdAt: DateTime.now(),
      total: cart.total,
      paymentMethod: method,
      gatewayReference: result.reference,
      items: cart.lines
          .map((line) => SaleItem(
                productId: line.product.id!,
                productName: line.product.name,
                unitPrice: line.product.price,
                quantity: line.quantity,
              ))
          .toList(),
    );

    await DatabaseHelper.instance.insertSale(sale);

    if (!mounted) return;
    cart.clear();
    await context.read<InventoryProvider>().loadProducts();

    if (!mounted) return;
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم إتمام البيع بنجاح')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(20),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const Text('اختر طريقة الدفع', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w700)),
          const SizedBox(height: 16),
          if (_processing)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 24),
              child: Center(child: CircularProgressIndicator()),
            )
          else ...[
            _MethodTile(icon: Icons.payments_outlined, label: 'نقدًا', onTap: () => _pay(PaymentMethod.cash)),
            const SizedBox(height: 10),
            _MethodTile(icon: Icons.credit_card, label: 'بطاقة', onTap: () => _pay(PaymentMethod.card)),
            const SizedBox(height: 10),
            _MethodTile(
              icon: Icons.account_balance_wallet_outlined,
              label: 'محفظة إلكترونية',
              onTap: () => _pay(PaymentMethod.wallet),
            ),
          ],
        ],
      ),
    );
  }
}

class _MethodTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _MethodTile({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.border),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppColors.primary),
            const SizedBox(width: 12),
            Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16)),
          ],
        ),
      ),
    );
  }
}
