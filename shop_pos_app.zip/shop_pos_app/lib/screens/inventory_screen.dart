import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../services/providers.dart';
import '../theme/app_theme.dart';
import '../widgets/empty_state.dart';
import 'product_form_screen.dart';

class InventoryScreen extends StatelessWidget {
  const InventoryScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final inventory = context.watch<InventoryProvider>();
    final formatter = NumberFormat.currency(locale: 'en', symbol: AppConfig.currencySymbol, decimalDigits: 2);

    return Scaffold(
      appBar: AppBar(title: const Text('المخزون')),
      floatingActionButton: FloatingActionButton(
        backgroundColor: AppColors.primary,
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const ProductFormScreen()),
        ),
        child: const Icon(Icons.add, color: Colors.white),
      ),
      body: inventory.products.isEmpty
          ? EmptyState(
              icon: Icons.inventory_2_outlined,
              title: 'لا توجد منتجات بعد',
              message: 'أضف أول منتج للبدء في البيع.',
              actionLabel: 'إضافة منتج',
              onAction: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ProductFormScreen()),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(12),
              itemCount: inventory.products.length,
              separatorBuilder: (_, __) => const SizedBox(height: 8),
              itemBuilder: (context, index) {
                final product = inventory.products[index];
                final lowStock = product.stockQuantity <= 3;
                return Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.surface,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.border),
                  ),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(product.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                            const SizedBox(height: 4),
                            Text(
                              'الكمية: ${product.stockQuantity}',
                              style: TextStyle(
                                color: lowStock ? AppColors.danger : AppColors.textSecondary,
                                fontSize: 13,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Text(
                        formatter.format(product.price),
                        style: const TextStyle(fontWeight: FontWeight.w700, color: AppColors.primary),
                      ),
                      IconButton(
                        icon: const Icon(Icons.edit_outlined),
                        onPressed: () => Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => ProductFormScreen(existing: product)),
                        ),
                      ),
                      IconButton(
                        icon: const Icon(Icons.delete_outline, color: AppColors.danger),
                        onPressed: () => context.read<InventoryProvider>().deleteProduct(product.id!),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}
