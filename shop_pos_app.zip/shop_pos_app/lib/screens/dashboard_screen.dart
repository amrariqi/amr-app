import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../db/database_helper.dart';
import '../theme/app_theme.dart';

class DashboardScreen extends StatefulWidget {
  final VoidCallback onStartSale;
  final VoidCallback onOpenInventory;
  final VoidCallback onOpenReports;

  const DashboardScreen({
    super.key,
    required this.onStartSale,
    required this.onOpenInventory,
    required this.onOpenReports,
  });

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  double _todayTotal = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadToday();
  }

  Future<void> _loadToday() async {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day);
    final end = start.add(const Duration(days: 1));
    final total = await DatabaseHelper.instance.getTotalSalesBetween(start, end);
    if (!mounted) return;
    setState(() {
      _todayTotal = total;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat.currency(locale: 'en', symbol: AppConfig.currencySymbol, decimalDigits: 2);

    return Scaffold(
      appBar: AppBar(title: const Text('الرئيسية')),
      body: RefreshIndicator(
        onRefresh: _loadToday,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppColors.primary,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('مبيعات اليوم', style: TextStyle(color: Colors.white70, fontSize: 14)),
                  const SizedBox(height: 8),
                  _loading
                      ? const SizedBox(
                          height: 32,
                          width: 32,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3),
                        )
                      : Text(
                          formatter.format(_todayTotal),
                          style: const TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.w800),
                        ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            _QuickAction(icon: Icons.point_of_sale, label: 'بيع جديد', onTap: widget.onStartSale),
            const SizedBox(height: 12),
            _QuickAction(icon: Icons.inventory_2_outlined, label: 'إدارة المخزون', onTap: widget.onOpenInventory),
            const SizedBox(height: 12),
            _QuickAction(icon: Icons.bar_chart_outlined, label: 'التقارير', onTap: widget.onOpenReports),
          ],
        ),
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  const _QuickAction({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: AppColors.border),
        ),
        child: Row(
          children: [
            Icon(icon, color: AppColors.primary),
            const SizedBox(width: 12),
            Expanded(child: Text(label, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16))),
          ],
        ),
      ),
    );
  }
}
