import 'package:flutter/material.dart';
import 'dashboard_screen.dart';
import 'inventory_screen.dart';
import 'pos_screen.dart';
import 'reports_screen.dart';

class RootShell extends StatefulWidget {
  const RootShell({super.key});

  @override
  State<RootShell> createState() => _RootShellState();
}

class _RootShellState extends State<RootShell> {
  int _index = 0;

  void _goTo(int index) => setState(() => _index = index);

  @override
  Widget build(BuildContext context) {
    final screens = [
      DashboardScreen(
        onStartSale: () => _goTo(1),
        onOpenInventory: () => _goTo(2),
        onOpenReports: () => _goTo(3),
      ),
      const PosScreen(),
      const InventoryScreen(),
      const ReportsScreen(),
    ];

    return Scaffold(
      body: IndexedStack(index: _index, children: screens),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: _goTo,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_outlined), label: 'الرئيسية'),
          BottomNavigationBarItem(icon: Icon(Icons.point_of_sale_outlined), label: 'بيع'),
          BottomNavigationBarItem(icon: Icon(Icons.inventory_2_outlined), label: 'المخزون'),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart_outlined), label: 'التقارير'),
        ],
      ),
    );
  }
}
