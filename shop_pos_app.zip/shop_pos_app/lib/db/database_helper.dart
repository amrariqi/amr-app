import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import '../models/models.dart';

/// طبقة قاعدة البيانات المحلية (SQLite). كل عملية بيع تُحفظ هنا فورًا بغض
/// النظر عن وجود إنترنت من عدمه (مبدأ Offline-First) — لا حاجة لأي خادم
/// حتى تعمل شاشة البيع والمخزون والتقارير.
class DatabaseHelper {
  DatabaseHelper._internal();
  static final DatabaseHelper instance = DatabaseHelper._internal();

  Database? _db;

  Future<Database> get database async {
    _db ??= await _initDb();
    return _db!;
  }

  Future<Database> _initDb() async {
    final dbPath = await getDatabasesPath();
    final fullPath = join(dbPath, 'shop_pos.db');
    return openDatabase(
      fullPath,
      version: 1,
      onCreate: _onCreate,
    );
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        price REAL NOT NULL,
        stock_quantity INTEGER NOT NULL DEFAULT 0,
        category TEXT,
        barcode TEXT
      )
    ''');

    await db.execute('''
      CREATE TABLE sales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        created_at TEXT NOT NULL,
        total REAL NOT NULL,
        payment_method TEXT NOT NULL,
        gateway_reference TEXT,
        synced INTEGER NOT NULL DEFAULT 0
      )
    ''');

    await db.execute('''
      CREATE TABLE sale_items (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sale_id INTEGER NOT NULL,
        product_id INTEGER NOT NULL,
        product_name TEXT NOT NULL,
        unit_price REAL NOT NULL,
        quantity INTEGER NOT NULL,
        FOREIGN KEY (sale_id) REFERENCES sales (id)
      )
    ''');
  }

  // ---------------- المنتجات ----------------

  Future<int> insertProduct(Product product) async {
    final db = await database;
    return db.insert('products', product.toMap()..remove('id'));
  }

  Future<List<Product>> getProducts() async {
    final db = await database;
    final rows = await db.query('products', orderBy: 'name COLLATE NOCASE ASC');
    return rows.map((row) => Product.fromMap(row)).toList();
  }

  Future<int> updateProduct(Product product) async {
    final db = await database;
    return db.update(
      'products',
      product.toMap(),
      where: 'id = ?',
      whereArgs: [product.id],
    );
  }

  Future<int> deleteProduct(int id) async {
    final db = await database;
    return db.delete('products', where: 'id = ?', whereArgs: [id]);
  }

  Future<void> adjustStock(int productId, int delta) async {
    final db = await database;
    await db.rawUpdate(
      'UPDATE products SET stock_quantity = stock_quantity + ? WHERE id = ?',
      [delta, productId],
    );
  }

  // ---------------- المبيعات ----------------

  Future<int> insertSale(Sale sale) async {
    final db = await database;
    return db.transaction<int>((txn) async {
      final saleId = await txn.insert('sales', sale.toMap()..remove('id'));
      for (final item in sale.items) {
        final itemMap = item.toMap()
          ..remove('id')
          ..['sale_id'] = saleId;
        await txn.insert('sale_items', itemMap);
        await txn.rawUpdate(
          'UPDATE products SET stock_quantity = stock_quantity - ? WHERE id = ?',
          [item.quantity, item.productId],
        );
      }
      return saleId;
    });
  }

  Future<List<Sale>> getSales({DateTime? from, DateTime? to}) async {
    final db = await database;
    String? where;
    List<Object?>? whereArgs;
    if (from != null && to != null) {
      where = 'created_at BETWEEN ? AND ?';
      whereArgs = [from.toIso8601String(), to.toIso8601String()];
    }
    final saleRows = await db.query(
      'sales',
      where: where,
      whereArgs: whereArgs,
      orderBy: 'created_at DESC',
    );

    final sales = <Sale>[];
    for (final row in saleRows) {
      final itemRows = await db.query(
        'sale_items',
        where: 'sale_id = ?',
        whereArgs: [row['id']],
      );
      final items = itemRows.map((i) => SaleItem.fromMap(i)).toList();
      sales.add(Sale.fromMap(row, items: items));
    }
    return sales;
  }

  Future<double> getTotalSalesBetween(DateTime from, DateTime to) async {
    final db = await database;
    final result = await db.rawQuery(
      'SELECT COALESCE(SUM(total), 0) as total FROM sales WHERE created_at BETWEEN ? AND ?',
      [from.toIso8601String(), to.toIso8601String()],
    );
    return (result.first['total'] as num).toDouble();
  }
}
