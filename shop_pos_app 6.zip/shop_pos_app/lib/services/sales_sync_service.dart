import 'dart:async';
import 'dart:convert';
import 'package:http/http.dart' as http;
import '../config/backend_config.dart';
import '../db/database_helper.dart';
import '../models/models.dart';

/// يرفع نسخة من كل عملية بيع مكتملة (نقدًا أو بالبطاقة) إلى قاعدة بيانات
/// Supabase السحابية — كنسخة احتياطية وتمهيدًا لتقارير موحّدة لاحقًا فقط.
///
/// مهم: قاعدة البيانات المحلية (SQLite) تبقى دائمًا المصدر الأساسي الذي
/// يعمل البيع الفعلي عليه بدون إنترنت؛ هذه الخدمة لا تُنتظَر أبدًا أثناء
/// إتمام عملية بيع ولا يمكن أن تمنعها أو تُبطئها. إن فشل الرفع (لا إنترنت
/// وقت البيع مثلًا)، تبقى العملية محفوظة محليًا بعلامة "غير مُزامَنة"
/// (synced = 0) وتُعاد محاولة رفعها تلقائيًا لاحقًا عبر [syncPending].
///
/// نرسل نفس المعرّف (client_uuid) في كل محاولة رفع مع رأس
/// "Prefer: resolution=merge-duplicates" — فتكرار المحاولة لنفس العملية
/// (بعد استعادة الاتصال مثلًا) يُحدِّث نفس الصف بدل إنشاء نسخة مكررة.
class SalesSyncService {
  static Map<String, String> _headers() => {
        'Content-Type': 'application/json',
        'apikey': BackendConfig.supabaseAnonKey,
        'Authorization': 'Bearer ${BackendConfig.supabaseAnonKey}',
        'Prefer': 'resolution=merge-duplicates',
      };

  /// يحاول رفع عملية بيع واحدة (مع أصنافها). يُعيد true عند النجاح فقط،
  /// ويُحدِّث علامة "synced" محليًا بنفسه عند النجاح. لا يرمي أي استثناء
  /// أبدًا — أي خطأ (شبكة، خادم، إلخ) يُعامَل كفشل صامت يُعاد تجربته لاحقًا.
  static Future<bool> pushSale(Sale sale) async {
    if (sale.id == null) return false;

    try {
      final saleRes = await http.post(
        Uri.parse('${BackendConfig.supabaseProjectUrl}/rest/v1/sales'),
        headers: _headers(),
        body: jsonEncode({
          'id': sale.clientUuid,
          'client_uuid': sale.clientUuid,
          'status': 'completed',
          // القيمة المخزَّنة محليًا لطريقة "موافقة هاتفية" هي manualApproval
          // (اسم عنصر enum في Dart)، لكن قيد التحقق (CHECK) على عمود
          // payment_method في Supabase يقبل manual_approval بالأسلوب المتّبع
          // لبقية القيم هناك (cash/card/wallet) — لذلك نُترجمها هنا فقط عند
          // الرفع للسحابة، دون المساس بالتخزين المحلي.
          'payment_method': sale.paymentMethod == POSPaymentMethod.manualApproval
              ? 'manual_approval'
              : sale.paymentMethod.storageValue,
          'subtotal_cents': (sale.total * 100).round(),
          'total_cents': (sale.total * 100).round(),
          'currency': 'usd',
          if (sale.paymentMethod == POSPaymentMethod.card && sale.gatewayReference != null)
            'stripe_payment_intent_id': sale.gatewayReference,
          // العملية "الهاتفية" غير مُتحقَّق منها إلكترونيًا (راجع
          // ManualApprovalGateway) — تُحفظ كملاحظة نصية واضحة، وليست في
          // عمود stripe_payment_intent_id، حتى لا تُخلَط بعملية Stripe
          // حقيقية عند مراجعة التقارير السحابية لاحقًا.
          if (sale.paymentMethod == POSPaymentMethod.manualApproval && sale.gatewayReference != null)
            'note': 'موافقة هاتفية يدوية — ${sale.gatewayReference}',
          'created_at': sale.createdAt.toIso8601String(),
        }),
      );
      if (saleRes.statusCode >= 300) {
        return false;
      }

      if (sale.items.isNotEmpty) {
        final itemsRes = await http.post(
          Uri.parse('${BackendConfig.supabaseProjectUrl}/rest/v1/sale_items'),
          headers: _headers(),
          body: jsonEncode(sale.items
              .map((item) => {
                    'sale_id': sale.clientUuid,
                    'name': item.productName,
                    'is_custom': false,
                    'unit_price_cents': (item.unitPrice * 100).round(),
                    'quantity': item.quantity,
                    'line_total_cents': (item.lineTotal * 100).round(),
                  })
              .toList()),
        );
        if (itemsRes.statusCode >= 300) {
          return false;
        }
      }

      await DatabaseHelper.instance.markSynced(sale.id!);

      // عمود card_approval_code في Supabase مخصَّص لرمز موافقة حقيقي صادر
      // عن شبكة البطاقة، "لا يُفترض أن يضبطه العميل مطلقًا" (راجع تعليق
      // العمود في قاعدة البيانات) — الثقة فيه تأتي من كونه يُجلب من Stripe
      // نفسها عبر Edge Function التي تحمل المفتاح السري وحدها، وليس من رقم
      // يُنشئه التطبيق أو الكاشير. لذلك هذا الاستدعاء غير حرج تمامًا (لا
      // يُفشِل المزامنة نفسها ولا يُعاد تجربته لاحقًا إن تعذّر — العملية
      // نفسها مُزامَنة ومكتملة بنجاح بدونه، فقط دون هذا الرقم الإضافي).
      if (sale.paymentMethod == POSPaymentMethod.card) {
        unawaited(_resolveCardApprovalCode(sale));
      }

      return true;
    } catch (_) {
      return false;
    }
  }

  /// يطلب من Edge Function (وهي الوحيدة التي تحمل مفتاح Stripe السري) رمز
  /// الموافقة الحقيقي لعملية الدفع بالبطاقة، ثم يحفظه في نفس صف المبيعة على
  /// Supabase. لا يُستخدَم لأي غرض آخر ولا يُعاد تجربته تلقائيًا — مجرّد
  /// تفصيل إضافي في السجل السحابي للإيصال، وليس جزءًا من إتمام البيع نفسه.
  static Future<void> _resolveCardApprovalCode(Sale sale) async {
    final paymentIntentId = sale.gatewayReference;
    if (paymentIntentId == null || !paymentIntentId.startsWith('pi_')) return;

    try {
      final lookupRes = await http.post(
        Uri.parse('${BackendConfig.supabaseProjectUrl}/functions/v1/create-payment-intent'),
        headers: {
          'Content-Type': 'application/json',
          'apikey': BackendConfig.supabaseAnonKey,
          'Authorization': 'Bearer ${BackendConfig.supabaseAnonKey}',
        },
        body: jsonEncode({'paymentIntentId': paymentIntentId}),
      );
      if (lookupRes.statusCode != 200) return;

      final data = jsonDecode(lookupRes.body) as Map<String, dynamic>;
      final approvalCode = data['approvalCode'] as String?;
      if (approvalCode == null) return;

      await http.patch(
        Uri.parse(
          '${BackendConfig.supabaseProjectUrl}/rest/v1/sales?client_uuid=eq.${sale.clientUuid}',
        ),
        headers: {
          'Content-Type': 'application/json',
          'apikey': BackendConfig.supabaseAnonKey,
          'Authorization': 'Bearer ${BackendConfig.supabaseAnonKey}',
        },
        body: jsonEncode({'card_approval_code': approvalCode}),
      );
    } catch (_) {
      // غير حرج — راجع التعليق أعلى الدالة.
    }
  }

  /// يُستدعى عند بدء التطبيق (ولا بأس بتكراره لاحقًا) لإعادة محاولة رفع أي
  /// عمليات بيع نجحت محليًا سابقًا لكن لم تُرفَع بعد. صامت تمامًا ولا يؤخر
  /// فتح التطبيق — يُشغَّل دون انتظار (unawaited) من main.dart.
  static Future<void> syncPending() async {
    try {
      final pending = await DatabaseHelper.instance.getUnsyncedSales();
      for (final sale in pending) {
        await pushSale(sale);
      }
    } catch (_) {
      // فشل الفحص نفسه (لا إنترنت مثلًا) — نتجاهله بصمت، ستُعاد المحاولة
      // في المرة القادمة التي يُفتح فيها التطبيق.
    }
  }
}
