import 'dart:convert';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:http/http.dart' as http;
import '../config/backend_config.dart';
import '../models/models.dart';

/// نتيجة عملية دفع — تحتوي فقط على حالة النجاح ورقم مرجعي، ولا تحتوي
/// ولن تحتوي أبدًا على رقم بطاقة أو CVV.
class PaymentResult {
  final bool success;
  final String? reference;
  final String? errorMessage;

  const PaymentResult({
    required this.success,
    this.reference,
    this.errorMessage,
  });
}

abstract class PaymentGateway {
  // note: مُستخدَم فقط من ManualApprovalGateway (رمز الموافقة الهاتفية) —
  // بقية البوابات تتجاهله.
  Future<PaymentResult> charge({required double amount, String? note});
}

/// الدفع النقدي يكتمل محليًا وفوريًا — لا حاجة لأي اتصال بالإنترنت.
class CashPaymentGateway implements PaymentGateway {
  @override
  Future<PaymentResult> charge({required double amount, String? note}) async {
    return PaymentResult(
      success: true,
      reference: 'CASH-${DateTime.now().millisecondsSinceEpoch}',
    );
  }
}

// =============================================================================
// الدفع بالبطاقة عبر Stripe.
//
// هذا التطبيق لا يرى رقم البطاقة ولا CVV في أي لحظة: الحقول التي يكتب فيها
// الزبون رقم بطاقته هي واجهة PaymentSheet الجاهزة من حزمة flutter_stripe،
// وهي تُرسِل البيانات مباشرة ومشفَّرة إلى خوادم Stripe — لا تمر عبر خادمنا
// ولا عبر هذا التطبيق. كل ما يحدث هنا:
//   1) نطلب من Edge Function الخاصة بنا (على Supabase) إنشاء "عملية دفع"
//      (PaymentIntent)؛ هي وحدها من تحمل مفتاح Stripe السري، ولا يصل هذا
//      المفتاح إلى الهاتف إطلاقًا.
//   2) نعرض PaymentSheet للزبون ليُدخل بطاقته مباشرة إلى Stripe.
//   3) عند النجاح، نحفظ رقم العملية المرجعي فقط (reference) في سجل المبيعات.
//
// راجع supabase/functions/create-payment-intent لكود الخادم، وملف
// lib/config/backend_config.dart لعنوان المشروع ومفاتيحه العامة.
class StripeCardGateway implements PaymentGateway {
  @override
  Future<PaymentResult> charge({required double amount, String? note}) async {
    try {
      final amountInSubunits = (amount * 100).round(); // مثال: 10.50 → 1050

      final response = await http.post(
        Uri.parse('${BackendConfig.supabaseProjectUrl}/functions/v1/create-payment-intent'),
        headers: {
          'Content-Type': 'application/json',
          'apikey': BackendConfig.supabaseAnonKey,
          'Authorization': 'Bearer ${BackendConfig.supabaseAnonKey}',
        },
        body: jsonEncode({'amountCents': amountInSubunits, 'currency': 'usd'}),
      );

      final data = jsonDecode(response.body) as Map<String, dynamic>;

      if (response.statusCode != 200 || data['clientSecret'] == null) {
        return PaymentResult(
          success: false,
          errorMessage: data['error']?.toString() ?? 'تعذّر إنشاء عملية الدفع',
        );
      }

      final clientSecret = data['clientSecret'] as String;
      final paymentIntentId = data['paymentIntentId'] as String?;

      await Stripe.instance.initPaymentSheet(
        paymentSheetParameters: SetupPaymentSheetParameters(
          paymentIntentClientSecret: clientSecret,
          merchantDisplayName: 'نظام نقاط البيع',

          // Google Pay: يظهر كخيار دفع إضافي داخل نافذة الدفع مباشرة إن كان
          // متاحًا على جهاز الزبون. ملاحظة مهمة: merchantCountryCode هنا
          // مؤقت بـ 'US' لحين معرفة الدولة الفعلية لحساب Stripe — يجب
          // تغييره لرمز الدولة الحقيقي (مثلاً 'SA' للسعودية، 'AE' للإمارات)
          // بمجرد تأكيده، وإلا قد لا يعمل بشكل صحيح خارج أمريكا.
          googlePay: const PaymentSheetGooglePay(
            merchantCountryCode: 'US',
            currencyCode: 'USD',
            testEnv: true, // نستخدم مفاتيح Stripe التجريبية (pk_test_) حاليًا.
          ),

          // Stripe Link: حفظ بيانات البطاقة لتسريع الدفعات القادمة — يظهر
          // تلقائيًا فقط إذا كان مفعّلاً من لوحة تحكم Stripe نفسها (وليس من
          // هذا الكود)؛ راجع Dashboard ← Settings ← Payment methods هناك.
          linkDisplayParams: const LinkDisplayParams(linkDisplay: LinkDisplay.automatic),

          // مسح البطاقة بالكاميرا (بدل كتابة الرقم يدويًا) يظهر تلقائيًا في
          // شاشة إدخال البطاقة ضمن PaymentSheet نفسها — لا يحتاج إعدادًا هنا.
        ),
      );

      await Stripe.instance.presentPaymentSheet();

      return PaymentResult(success: true, reference: paymentIntentId ?? clientSecret);
    } on StripeException catch (e) {
      // المستخدم ألغى الدفع أو رفضت البطاقة — ليست حالة خطأ غير متوقعة.
      return PaymentResult(
        success: false,
        errorMessage: e.error.localizedMessage ?? 'تم إلغاء الدفع',
      );
    } catch (e) {
      return PaymentResult(success: false, errorMessage: 'تعذّر إتمام الدفع: $e');
    }
  }
}

/// المحفظة الإلكترونية/التحويل البنكي المحلي يحتاج بوابة الدولة المحدَّدة
/// (راجع الرسالة أدناه) — Stripe لا يغطي هذه الطرق في كل الدول العربية.
class WalletGatewayPending implements PaymentGateway {
  @override
  Future<PaymentResult> charge({required double amount, String? note}) async {
    return const PaymentResult(
      success: false,
      errorMessage:
          'الدفع بالمحفظة الإلكترونية/التحويل البنكي يحتاج بوابة محلية إضافية — أخبرني باسم دولتك لأربطها.',
    );
  }
}

// =============================================================================
// "موافقة هاتفية" (Voice/Manual Authorization).
//
// آلية حقيقية شائعة في الأماكن السياحية أو عند ضعف الاتصال: يتصل البنك
// بحامل البطاقة مباشرة، يؤكّد معه تفاصيل العملية، ثم يملي على الكاشير
// هاتفيًا رمز موافقة تُدخله يدويًا هنا لإتمام تسجيل البيع.
//
// تنبيه مهم ومقصود: Stripe لا يدعم هذه الآلية إطلاقًا (بنية قديمة تابعة
// للبنك المُصدِر مباشرة، مختلفة كليًا عن نظام Stripe الإلكتروني). لذلك
// هذه البوابة لا تتصل بأي خادم ولا تتحقق من صحة الرمز تقنيًا — فقط
// *تُسجِّل* الرمز الذي يكتبه الكاشير بعد نجاح المكالمة الفعلية مع العميل
// والبنك. الثقة هنا في تلك المكالمة نفسها، وليست ضمانًا تقنيًا من هذا
// التطبيق أو من Stripe. لهذا هي مفصولة دائمًا وبوضوح عن "بطاقة" (Stripe)
// في كل مكان — القوائم، السجلات، والتقارير — حتى لا تُخلَط بعملية
// مُتحقَّق منها إلكترونيًا.
class ManualApprovalGateway implements PaymentGateway {
  // معظم رموز الموافقة الصادرة عن شبكات البطاقات (Visa/Mastercard وغيرها)
  // مكوَّنة من 6 أرقام — نتحقق من هذا الشكل هنا أيضًا كطبقة حماية إضافية،
  // رغم أن حقل الإدخال في الواجهة (payment_method_sheet.dart) يفرضه فعليًا.
  static final _codePattern = RegExp(r'^\d{6}$');

  @override
  Future<PaymentResult> charge({required double amount, String? note}) async {
    final code = note?.trim();
    if (code == null || !_codePattern.hasMatch(code)) {
      return const PaymentResult(
        success: false,
        errorMessage: 'رمز الموافقة يجب أن يتكون من 6 أرقام بالضبط',
      );
    }
    return PaymentResult(success: true, reference: 'MANUAL-$code');
  }
}

PaymentGateway gatewayFor(POSPaymentMethod method) {
  switch (method) {
    case POSPaymentMethod.cash:
      return CashPaymentGateway();
    case POSPaymentMethod.card:
      return StripeCardGateway();
    case POSPaymentMethod.wallet:
      return WalletGatewayPending();
    case POSPaymentMethod.manualApproval:
      return ManualApprovalGateway();
  }
}
