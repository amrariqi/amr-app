import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart' hide TextDirection;
import 'package:provider/provider.dart';
import '../db/database_helper.dart';
import '../models/models.dart';
import '../services/payment_gateway.dart';
import '../services/providers.dart';
import '../services/sales_sync_service.dart';
import '../theme/app_theme.dart';
import '../utils/uuid.dart';

class PaymentMethodSheet extends StatefulWidget {
  const PaymentMethodSheet({super.key});

  @override
  State<PaymentMethodSheet> createState() => _PaymentMethodSheetState();
}

class _PaymentMethodSheetState extends State<PaymentMethodSheet> {
  bool _processing = false;

  Future<void> _pay(POSPaymentMethod method, {String? manualNote}) async {
    final cart = context.read<CartProvider>();
    setState(() => _processing = true);

    final gateway = gatewayFor(method);
    final result = await gateway.charge(amount: cart.total, note: manualNote);

    if (!mounted) return;

    if (!result.success) {
      setState(() => _processing = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.errorMessage ?? 'تعذّر إتمام الدفع')),
      );
      return;
    }

    final sale = Sale(
      clientUuid: generateUuidV4(),
      createdAt: DateTime.now(),
      total: cart.total,
      paymentMethod: method,
      gatewayReference: result.reference,
      items: cart.lines
          .map((line) => SaleItem(
                productId: line.product.id!,
                productName: line.product.name,
                unitPrice: line.product.price,
                quantity: line.quantity,
              ))
          .toList(),
    );

    final saleId = await DatabaseHelper.instance.insertSale(sale);

    // محاولة رفع نسخة من العملية إلى Supabase كنسخة احتياطية/لتقارير
    // موحّدة — لا تُنتظَر ولا تمنع إتمام البيع أبدًا. إن فشلت (لا إنترنت
    // مثلًا) تبقى العملية محفوظة محليًا وتُعاد محاولتها لاحقًا تلقائيًا
    // (راجع main.dart وSalesSyncService.syncPending).
    unawaited(SalesSyncService.pushSale(sale.copyWith(id: saleId)));

    if (!mounted) return;
    cart.clear();
    await context.read<InventoryProvider>().loadProducts();

    if (!mounted) return;
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('تم إتمام البيع بنجاح')),
    );
  }

  // يطلب من الكاشير رمز الموافقة الذي أملاه البنك هاتفيًا (6 أرقام بالضبط
  // — لوحة مفاتيح رقمية فقط، ولا يُفعَّل زر "تأكيد" قبل اكتمالها)، ثم يتابع
  // البيع بنفس مسار _pay المعتاد (وإلا يُلغي بصمت إن ألغى الكاشير الحوار).
  Future<void> _payWithManualApproval() async {
    final controller = TextEditingController();
    final code = await showDialog<String>(
      context: context,
      builder: (dialogContext) => StatefulBuilder(
        builder: (context, setDialogState) {
          return AlertDialog(
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
            title: const Text('موافقة هاتفية'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'يُستخدم هذا عندما يتصل البنك بالعميل هاتفيًا ويؤكّد العملية '
                  'ويُملي رمز موافقة مكوَّن من 6 أرقام. أدخل الرمز نفسه هنا — '
                  'هذه العملية تُسجَّل يدويًا ولا تمر عبر Stripe.',
                  style: TextStyle(fontSize: 13, color: AppColors.textSecondary),
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: controller,
                  autofocus: true,
                  textDirection: TextDirection.ltr,
                  textAlign: TextAlign.center,
                  keyboardType: TextInputType.number,
                  inputFormatters: [FilteringTextInputFormatter.digitsOnly],
                  maxLength: 6,
                  style: const TextStyle(fontSize: 22, letterSpacing: 6),
                  decoration: const InputDecoration(labelText: 'رمز الموافقة (6 أرقام)'),
                  onChanged: (_) => setDialogState(() {}),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(dialogContext).pop(),
                child: const Text('إلغاء'),
              ),
              FilledButton(
                onPressed: controller.text.length == 6
                    ? () => Navigator.of(dialogContext).pop(controller.text)
                    : null,
                child: const Text('تأكيد'),
              ),
            ],
          );
        },
      ),
    );

    if (code == null || code.trim().isEmpty) return; // ألغى الكاشير
    if (!mounted) return;
    await _pay(POSPaymentMethod.manualApproval, manualNote: code);
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final formatter = NumberFormat.currency(locale: 'en', symbol: AppConfig.currencySymbol, decimalDigits: 2);

    return Container(
      decoration: const BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(4)),
              ),
            ),
            const SizedBox(height: 18),
            const Text('اختر طريقة الدفع', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(
              'المبلغ الإجمالي ${formatter.format(cart.total)}',
              style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 18),
            if (_processing)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(child: CircularProgressIndicator()),
              )
            else ...[
              _MethodTile(
                icon: Icons.payments_outlined,
                label: 'نقدًا',
                subtitle: 'دفع فوري بدون اتصال بالإنترنت',
                onTap: () => _pay(POSPaymentMethod.cash),
              ),
              const SizedBox(height: 10),
              _MethodTile(
                icon: Icons.credit_card,
                label: 'بطاقة',
                subtitle: 'عبر Stripe — آمن ومشفّر بالكامل',
                onTap: () => _pay(POSPaymentMethod.card),
              ),
              const SizedBox(height: 10),
              _MethodTile(
                icon: Icons.account_balance_wallet_outlined,
                label: 'محفظة إلكترونية',
                subtitle: 'تحويل بنكي أو محفظة محلية',
                onTap: () => _pay(POSPaymentMethod.wallet),
              ),
              const SizedBox(height: 10),
              _MethodTile(
                icon: Icons.phone_forwarded_outlined,
                label: 'موافقة هاتفية',
                subtitle: 'تأكيد يدوي عبر اتصال البنك',
                onTap: _payWithManualApproval,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _MethodTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final VoidCallback onTap;

  const _MethodTile({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: AppDecorations.card(radius: 16),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: AppColors.primary),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                ],
              ),
            ),
            const Icon(Icons.chevron_left, color: AppColors.textSecondary),
          ],
        ),
      ),
    );
  }
}
