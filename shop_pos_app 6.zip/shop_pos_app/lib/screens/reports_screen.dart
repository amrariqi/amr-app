import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import '../db/database_helper.dart';
import '../models/models.dart';
import '../theme/app_theme.dart';
import '../widgets/empty_state.dart';

class ReportsScreen extends StatefulWidget {
  const ReportsScreen({super.key});

  @override
  State<ReportsScreen> createState() => _ReportsScreenState();
}

class _ReportsScreenState extends State<ReportsScreen> {
  List<Sale> _sales = [];
  bool _loading = true;
  double _todayTotal = 0;
  double _weekTotal = 0;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final sales = await DatabaseHelper.instance.getSales();

    final now = DateTime.now();
    final todayStart = DateTime(now.year, now.month, now.day);
    final weekStart = todayStart.subtract(Duration(days: now.weekday - 1)); // بداية الأسبوع (الاثنين)
    final todayTotal = await DatabaseHelper.instance.getTotalSalesBetween(
      todayStart,
      todayStart.add(const Duration(days: 1)),
    );
    final weekTotal = await DatabaseHelper.instance.getTotalSalesBetween(
      weekStart,
      todayStart.add(const Duration(days: 1)),
    );

    if (!mounted) return;
    setState(() {
      _sales = sales;
      _todayTotal = todayTotal;
      _weekTotal = weekTotal;
      _loading = false;
    });
  }

  IconData _iconFor(POSPaymentMethod method) {
    switch (method) {
      case POSPaymentMethod.cash:
        return Icons.payments_outlined;
      case POSPaymentMethod.card:
        return Icons.credit_card;
      case POSPaymentMethod.wallet:
        return Icons.account_balance_wallet_outlined;
      case POSPaymentMethod.manualApproval:
        return Icons.phone_forwarded_outlined;
    }
  }

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat.currency(locale: 'en', symbol: AppConfig.currencySymbol, decimalDigits: 2);
    final dateFormatter = DateFormat('yyyy/MM/dd – HH:mm');

    if (_loading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }

    return Scaffold(
      appBar: AppBar(title: const Text('التقارير')),
      body: RefreshIndicator(
        onRefresh: _load,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Row(
              children: [
                Expanded(child: _StatCard(label: 'اليوم', value: formatter.format(_todayTotal))),
                const SizedBox(width: 12),
                Expanded(child: _StatCard(label: 'هذا الأسبوع', value: formatter.format(_weekTotal))),
              ],
            ),
            const SizedBox(height: 20),
            if (_sales.isEmpty)
              const Padding(
                padding: EdgeInsets.only(top: 40),
                child: EmptyState(
                  icon: Icons.receipt_long_outlined,
                  title: 'لا توجد مبيعات بعد',
                  message: 'ستظهر هنا كل عملية بيع تتم في المحل.',
                ),
              )
            else
              ...List.generate(_sales.length, (index) {
                final sale = _sales[index];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: Container(
                    padding: const EdgeInsets.all(14),
                    decoration: AppDecorations.card(radius: 14),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(9),
                          decoration: BoxDecoration(
                            color: AppColors.primary.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Icon(_iconFor(sale.paymentMethod), color: AppColors.primary, size: 18),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                dateFormatter.format(sale.createdAt),
                                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                '${sale.items.length} صنف · ${sale.paymentMethod.label}',
                                style: const TextStyle(color: AppColors.textSecondary, fontSize: 12),
                              ),
                            ],
                          ),
                        ),
                        Text(
                          formatter.format(sale.total),
                          style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary),
                        ),
                      ],
                    ),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }
}

class _StatCard extends StatelessWidget {
  final String label;
  final String value;
  const _StatCard({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: AppDecorations.card(radius: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary, fontWeight: FontWeight.w600)),
          const SizedBox(height: 6),
          Text(
            value,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800, color: AppColors.primary),
          ),
        ],
      ),
    );
  }
}
