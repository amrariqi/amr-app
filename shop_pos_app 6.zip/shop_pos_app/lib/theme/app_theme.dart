import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// هوية بصرية مقصودة لتطبيق متجر: أخضر مطفأ (ثقة وهدوء مالي) + كهرماني
/// دافئ (لون الإيصالات) على خلفية بلون الورق — بدلًا من التدرج البنفسجي
/// الجاهز الشائع في العروض التقنية التلقائية.
class AppColors {
  static const primary = Color(0xFF0F6B5C);
  static const primaryDark = Color(0xFF0B4F44);
  static const primaryLight = Color(0xFF15A085);
  static const accent = Color(0xFFC97B2E);
  static const background = Color(0xFFFAF7F2);
  static const surface = Color(0xFFFFFFFF);
  static const surfaceAlt = Color(0xFFF2EEE5);
  static const textPrimary = Color(0xFF1C1B19);
  static const textSecondary = Color(0xFF6B6660);
  static const success = Color(0xFF2E7D5B);
  static const danger = Color(0xFFB3402A);
  static const border = Color(0xFFE7E2D9);
  static const shadow = Color(0x1A1C1B19);
}

/// رمز عملة عام مؤقت (¤) لحين تحديد بلد التشغيل وبوابة الدفع.
class AppConfig {
  static const String currencySymbol = '¤';
}

/// زخارف مشتركة تُستخدم في كل الشاشات بدل تكرار BoxDecoration في كل مكان —
/// بطاقات مسطّحة بظل ناعم بدل الإطار الخطي التقليدي، بمظهر أقرب لواجهات
/// نقاط البيع الحديثة. مركزية هذا هنا تُسهّل أيضًا تغيير الشكل العام لاحقًا
/// من مكان واحد فقط.
class AppDecorations {
  static BoxDecoration card({double radius = 16, Color? color}) {
    return BoxDecoration(
      color: color ?? AppColors.surface,
      borderRadius: BorderRadius.circular(radius),
      boxShadow: const [
        BoxShadow(color: AppColors.shadow, blurRadius: 18, offset: Offset(0, 6)),
      ],
    );
  }
}

class AppTheme {
  static ThemeData get light {
    final base = ThemeData(
      useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primary),
      scaffoldBackgroundColor: AppColors.background,
    );

    final textTheme = GoogleFonts.tajawalTextTheme(base.textTheme).apply(
      bodyColor: AppColors.textPrimary,
      displayColor: AppColors.textPrimary,
    );

    return base.copyWith(
      textTheme: textTheme,
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.background,
        foregroundColor: AppColors.textPrimary,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 20),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
          elevation: 0,
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          backgroundColor: AppColors.primary,
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 22),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          textStyle: textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: AppColors.surfaceAlt,
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: BorderSide.none,
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(14),
          borderSide: const BorderSide(color: AppColors.primary, width: 1.6),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: AppColors.textPrimary,
        contentTextStyle: const TextStyle(color: Colors.white, fontSize: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }
}
