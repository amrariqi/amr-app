import 'dart:math';

// مولّد UUID (الإصدار 4) بسيط بدون أي حزمة خارجية — نستخدمه كمعرّف ثابت
// لكل عملية بيع لحظة إنشائها، يبقى نفسه محليًا وسحابيًا، ليكون رفع نفس
// العملية أكثر من مرة إلى Supabase (عند إعادة محاولة المزامنة) آمنًا ولا
// يُنشئ نسخًا مكررة.
String generateUuidV4() {
  final rnd = Random.secure();
  final bytes = List<int>.generate(16, (_) => rnd.nextInt(256));
  bytes[6] = (bytes[6] & 0x0F) | 0x40; // إصدار 4
  bytes[8] = (bytes[8] & 0x3F) | 0x80; // متغيّر RFC 4122

  String hex(int start, int end) => bytes
      .sublist(start, end)
      .map((b) => b.toRadixString(16).padLeft(2, '0'))
      .join();

  return '${hex(0, 4)}-${hex(4, 6)}-${hex(6, 8)}-${hex(8, 10)}-${hex(10, 16)}';
}
