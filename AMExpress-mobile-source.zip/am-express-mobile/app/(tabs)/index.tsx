import { useState } from "react";
import { ActivityIndicator, FlatList, Pressable, RefreshControl, Text, TextInput, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useApp } from "@/lib/app-context";
import { supabase, type Shipment } from "@/lib/supabase";

const navy = "#0B2036";
const orange = "#E87528";
const muted = "#667085";

function StatusPill({ status }: { status: string }) {
  return (
    <View style={styles.statusPill}>
      <Text style={styles.statusText}>{status || "قيد المعالجة"}</Text>
    </View>
  );
}

function LoginCard() {
  const { signInCustomer, error } = useApp();
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function submit() {
    setBusy(true);
    setMessage("");
    const result = await signInCustomer(email, phone, password);
    if (!result.ok) setMessage(result.message || "تعذر تسجيل الدخول");
    setBusy(false);
  }

  return (
    <View style={styles.loginCard}>
      <View style={styles.loginHeader}>
        <View style={styles.logoMark}><Ionicons name="boat-outline" color="#fff" size={30} /></View>
        <Text style={styles.loginTitle}>بوابة العميل</Text>
        <Text style={styles.loginSubtitle}>تابع شحناتك وفواتيرك من أي جهاز</Text>
      </View>
      <TextInput value={email} onChangeText={setEmail} placeholder="البريد الإلكتروني" placeholderTextColor="#98A2B3" keyboardType="email-address" autoCapitalize="none" style={styles.input} />
      <TextInput value={phone} onChangeText={setPhone} placeholder="رقم الهاتف المسجل" placeholderTextColor="#98A2B3" keyboardType="phone-pad" style={styles.input} />
      <TextInput value={password} onChangeText={setPassword} placeholder="كلمة المرور" placeholderTextColor="#98A2B3" secureTextEntry style={styles.input} />
      {message || error ? <Text style={styles.error}>{message || error}</Text> : null}
      <Pressable onPress={submit} disabled={busy} style={({ pressed }) => [styles.primaryButton, pressed && styles.pressed]}>
        {busy ? <ActivityIndicator color="#fff" /> : <Text style={styles.primaryButtonText}>دخول آمن</Text>}
      </Pressable>
      <Text style={styles.helper}>بيانات الدخول يصدرها فريق AM Express ويرتبط الحساب بملف العميل في الموقع.</Text>
    </View>
  );
}

function TrackingCard() {
  const [query, setQuery] = useState("");
  const [result, setResult] = useState<Shipment | null>(null);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function track() {
    if (!query.trim()) return;
    setBusy(true);
    setMessage("");
    setResult(null);
    const { data, error } = await supabase.from("shipments").select("id,tracking_no,customer_id,origin,destination,status,created_at,history").eq("tracking_no", query.trim()).maybeSingle();
    if (error || !data) setMessage("لم نجد شحنة بهذا الرقم");
    else setResult(data as Shipment);
    setBusy(false);
  }

  return (
    <View style={styles.card}>
      <View style={styles.sectionTitleRow}>
        <View><Text style={styles.cardTitle}>تتبع شحنة</Text><Text style={styles.cardSubtitle}>أدخل رقم التتبع من أي جهاز</Text></View>
        <Ionicons name="locate-outline" color={orange} size={27} />
      </View>
      <View style={styles.trackRow}>
        <TextInput value={query} onChangeText={setQuery} placeholder="AMX-..." placeholderTextColor="#98A2B3" autoCapitalize="characters" style={[styles.input, styles.trackInput]} />
        <Pressable onPress={track} style={styles.smallButton}>{busy ? <ActivityIndicator color="#fff" size="small" /> : <Ionicons name="search" color="#fff" size={20} />}</Pressable>
      </View>
      {message ? <Text style={styles.error}>{message}</Text> : null}
      {result ? <View style={styles.trackResult}><View style={styles.sectionTitleRow}><Text style={styles.tracking}>{result.tracking_no}</Text><StatusPill status={result.status} /></View><Text style={styles.route}>{result.origin || "—"} → {result.destination || "—"}</Text></View> : null}
    </View>
  );
}

export default function HomeScreen() {
  const { customer, shipments, invoices, loading, refreshing, refresh } = useApp();
  const router = useRouter();
  if (loading) return <ScreenContainer className="items-center justify-center"><ActivityIndicator color={orange} size="large" /></ScreenContainer>;

  return (
    <ScreenContainer containerClassName="bg-[#F4F7FB]" className="px-5">
      <FlatList
        data={customer ? shipments.slice(0, 3) : []}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor={orange} />}
        contentContainerStyle={styles.listContent}
        ListHeaderComponent={
          <View>
            <View style={styles.hero}>
              <Text style={styles.eyebrow}>AM EXPRESS LOGISTICS</Text>
              <Text style={styles.heroTitle}>{customer ? `مرحبًا، ${customer.name}` : "حلولك اللوجستية في مكان واحد"}</Text>
              <Text style={styles.heroText}>{customer ? "بياناتك وشحناتك وفواتيرك متزامنة مع موقع AM Express." : "تطبيق واحد لتتبع الشحنات وإدارة بياناتك من الهاتف."}</Text>
            </View>
            {!customer ? <><LoginCard /><TrackingCard /></> : <>
              <View style={styles.statsRow}><View style={styles.stat}><Text style={styles.statNumber}>{shipments.length}</Text><Text style={styles.statLabel}>شحناتك</Text></View><View style={styles.stat}><Text style={styles.statNumber}>{invoices.length}</Text><Text style={styles.statLabel}>فواتيرك</Text></View></View>
              <TrackingCard />
              <View style={[styles.card, { marginTop: 16 }]}><View style={styles.sectionTitleRow}><Text style={styles.cardTitle}>آخر الشحنات</Text><Pressable onPress={() => router.push("/(tabs)/shipments" as never)}><Text style={styles.link}>عرض الكل</Text></Pressable></View></View>
            </>}
          </View>
        }
        renderItem={({ item }) => <View style={styles.shipmentRow}><View style={{ flex: 1 }}><Text style={styles.tracking}>{item.tracking_no}</Text><Text style={styles.route}>{item.origin || "—"} → {item.destination || "—"}</Text></View><StatusPill status={item.status} /></View>}
        ListFooterComponent={customer ? <Pressable onPress={() => router.push("/(tabs)/invoices" as never)} style={styles.outlineButton}><Text style={styles.outlineText}>فتح الفواتير</Text></Pressable> : null}
      />
    </ScreenContainer>
  );
}

const styles = {
  listContent: { paddingTop: 18, paddingBottom: 34, maxWidth: 760, width: "100%", alignSelf: "center" },
  hero: { backgroundColor: navy, borderRadius: 26, padding: 22, marginBottom: 16 },
  eyebrow: { color: "#B9C8D9", fontSize: 13, textAlign: "right" },
  heroTitle: { color: "#fff", fontSize: 27, fontWeight: "800", textAlign: "right", marginTop: 10 },
  heroText: { color: "#D6E2EE", fontSize: 14, lineHeight: 22, textAlign: "right", marginTop: 7 },
  loginCard: { backgroundColor: "#fff", borderRadius: 24, padding: 20, borderWidth: 1, borderColor: "#E7ECF2", shadowColor: navy, shadowOpacity: 0.08, shadowRadius: 16, elevation: 2 },
  loginHeader: { alignItems: "center", marginBottom: 18 },
  logoMark: { width: 58, height: 58, borderRadius: 18, backgroundColor: navy, alignItems: "center", justifyContent: "center", marginBottom: 10 },
  loginTitle: { color: navy, fontSize: 22, fontWeight: "800" },
  loginSubtitle: { color: muted, marginTop: 5, textAlign: "center" },
  input: { backgroundColor: "#F8FAFC", borderColor: "#E1E7EF", borderWidth: 1, borderRadius: 13, paddingHorizontal: 14, paddingVertical: 13, color: navy, textAlign: "right", marginBottom: 10 },
  primaryButton: { backgroundColor: orange, borderRadius: 13, paddingVertical: 14, alignItems: "center" },
  primaryButtonText: { color: "#fff", fontWeight: "800", fontSize: 15 },
  helper: { color: muted, fontSize: 12, lineHeight: 19, textAlign: "center", marginTop: 12 },
  error: { color: "#C0392B", textAlign: "right", marginBottom: 10 },
  card: { backgroundColor: "#fff", borderRadius: 22, padding: 18, marginTop: 16, borderWidth: 1, borderColor: "#E7ECF2" },
  sectionTitleRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", gap: 12 },
  cardTitle: { color: navy, fontSize: 18, fontWeight: "800" },
  cardSubtitle: { color: muted, fontSize: 12, marginTop: 4 },
  trackRow: { flexDirection: "row", gap: 8, direction: "ltr", marginTop: 12 },
  trackInput: { flex: 1, marginBottom: 0, textAlign: "left" },
  smallButton: { width: 50, backgroundColor: orange, borderRadius: 13, alignItems: "center", justifyContent: "center" },
  trackResult: { marginTop: 14, padding: 14, backgroundColor: "#F7F9FC", borderRadius: 16 },
  tracking: { color: navy, fontWeight: "800" },
  route: { color: muted, marginTop: 7 },
  statusPill: { backgroundColor: "#E8F1FB", borderRadius: 99, paddingHorizontal: 10, paddingVertical: 5 },
  statusText: { color: navy, fontSize: 12, fontWeight: "700" },
  statsRow: { flexDirection: "row", gap: 10, marginBottom: 16 },
  stat: { flex: 1, backgroundColor: "#fff", borderRadius: 18, padding: 16, borderWidth: 1, borderColor: "#E7ECF2" },
  statNumber: { color: navy, fontSize: 25, fontWeight: "800", textAlign: "right" },
  statLabel: { color: muted, marginTop: 4, textAlign: "right" },
  shipmentRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 14, borderTopWidth: 1, borderTopColor: "#EEF1F5" },
  link: { color: orange, fontWeight: "700" },
  outlineButton: { borderWidth: 1, borderColor: navy, borderRadius: 13, paddingVertical: 13, alignItems: "center", marginTop: 16 },
  outlineText: { color: navy, fontWeight: "800" },
  pressed: { opacity: 0.85 },
} as const;
