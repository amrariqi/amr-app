import { useEffect, useState } from "react";
import { ActivityIndicator, Pressable, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { ScreenContainer } from "@/components/screen-container";
import { useApp } from "@/lib/app-context";
import { supabase } from "@/lib/supabase";

export default function OperationsScreen() {
  const { role } = useApp();
  const [stats, setStats] = useState({ shipments: 0, customers: 0, invoices: 0, quotes: 0 });
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState("");

  async function load() {
    if (role !== "admin" && role !== "staff") return;
    setBusy(true); setMessage("");
    const [shipments, customers, invoices, quotes] = await Promise.all([
      supabase.from("shipments").select("id", { count: "exact", head: true }),
      supabase.from("customers").select("id", { count: "exact", head: true }),
      supabase.from("invoices").select("id", { count: "exact", head: true }),
      supabase.from("quote_requests").select("id", { count: "exact", head: true }),
    ]);
    const failed = [shipments, customers, invoices, quotes].find((item) => item.error);
    if (failed?.error) setMessage("لا يمكن عرض إحصاءات العمليات بهذا الحساب");
    else setStats({ shipments: shipments.count || 0, customers: customers.count || 0, invoices: invoices.count || 0, quotes: quotes.count || 0 });
    setBusy(false);
  }
  useEffect(() => { void load(); }, [role]);

  if (role !== "admin" && role !== "staff") return <ScreenContainer containerClassName="bg-[#F4F7FB]" className="items-center justify-center px-5"><View style={styles.empty}><Ionicons name="lock-closed-outline" size={36} color="#E87528" /><Text style={styles.title}>هذه الشاشة للعمليات فقط</Text><Text style={styles.text}>لا تظهر لوحة الأدمن أو الموظفين لحسابات العملاء.</Text></View></ScreenContainer>;
  return <ScreenContainer containerClassName="bg-[#F4F7FB]" className="px-5"><View style={styles.container}><Text style={styles.heading}>مركز العمليات</Text><Text style={styles.subheading}>{role === "admin" ? "صلاحيات الأدمن" : "صلاحيات الموظف الممنوحة"}</Text>{message ? <Text style={styles.error}>{message}</Text> : null}<View style={styles.grid}>{[["الشحنات", stats.shipments, "cube-outline"], ["العملاء", stats.customers, "people-outline"], ["الفواتير", stats.invoices, "document-text-outline"], ["طلبات الأسعار", stats.quotes, "pricetag-outline"]].map(([label, value, icon]) => <View style={styles.metric} key={String(label)}><Ionicons name={icon as keyof typeof Ionicons.glyphMap} size={23} color="#E87528" /><Text style={styles.metricValue}>{busy ? "—" : value}</Text><Text style={styles.metricLabel}>{label}</Text></View>)}</View><Pressable onPress={load} style={styles.refresh}><Ionicons name="refresh-outline" size={19} color="#0B2036" /><Text style={styles.refreshText}>تحديث الإحصاءات</Text></Pressable></View></ScreenContainer>;
}
const styles = { container: { maxWidth: 760, width: "100%", alignSelf: "center", paddingTop: 20 }, heading: { color: "#0B2036", fontSize: 28, fontWeight: "800", textAlign: "right" }, subheading: { color: "#667085", marginTop: 6, textAlign: "right" }, grid: { flexDirection: "row", flexWrap: "wrap", gap: 12, marginTop: 22 }, metric: { width: "47%", flexGrow: 1, backgroundColor: "#fff", borderRadius: 19, padding: 18, borderWidth: 1, borderColor: "#E7ECF2" }, metricValue: { color: "#0B2036", fontSize: 28, fontWeight: "800", marginTop: 12, textAlign: "right" }, metricLabel: { color: "#667085", marginTop: 4, textAlign: "right" }, refresh: { flexDirection: "row", alignItems: "center", justifyContent: "center", gap: 8, borderWidth: 1, borderColor: "#CBD5E1", borderRadius: 13, paddingVertical: 13, marginTop: 18 }, refreshText: { color: "#0B2036", fontWeight: "800" }, error: { color: "#C0392B", textAlign: "right", marginTop: 15 }, empty: { width: "100%", maxWidth: 500, backgroundColor: "#fff", borderRadius: 22, padding: 28, alignItems: "center", borderWidth: 1, borderColor: "#E7ECF2" }, title: { color: "#0B2036", fontSize: 19, fontWeight: "800", marginTop: 10 }, text: { color: "#667085", textAlign: "center", marginTop: 8 } } as const;
