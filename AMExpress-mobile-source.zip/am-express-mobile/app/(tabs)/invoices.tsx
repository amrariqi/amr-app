import { FlatList, RefreshControl, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { ScreenContainer } from "@/components/screen-container";
import { useApp } from "@/lib/app-context";
import { money } from "@/lib/supabase";

export default function InvoicesScreen() {
  const { invoices, refreshing, refresh } = useApp();
  return (
    <ScreenContainer containerClassName="bg-[#F4F7FB]" className="px-5">
      <FlatList
        data={invoices}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor="#E87528" />}
        contentContainerStyle={styles.list}
        ListHeaderComponent={<View style={styles.header}><Text style={styles.title}>فواتيري</Text><Text style={styles.subtitle}>الفواتير الخاصة بحسابك فقط</Text></View>}
        ListEmptyComponent={<View style={styles.empty}><Ionicons name="document-text-outline" size={36} color="#E87528" /><Text style={styles.emptyTitle}>لا توجد فواتير متاحة</Text><Text style={styles.emptyText}>ستظهر فواتيرك هنا بعد إصدارها من فريق AM Express.</Text></View>}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View style={styles.row}><View style={{ flex: 1 }}><Text style={styles.invoiceNo}>{item.invoice_no}</Text><Text style={styles.date}>{item.issue_date || "—"}{item.due_date ? ` · الاستحقاق ${item.due_date}` : ""}</Text></View><View style={styles.invoiceIcon}><Ionicons name="receipt-outline" size={23} color="#E87528" /></View></View>
            <View style={styles.totalRow}><Text style={styles.total}>{money(item.total, item.currency || "USD")}</Text><View style={styles.status}><Text style={styles.statusText}>{item.status || "غير محددة"}</Text></View></View>
          </View>
        )}
      />
    </ScreenContainer>
  );
}

const styles = {
  list: { paddingTop: 20, paddingBottom: 30, maxWidth: 760, width: "100%", alignSelf: "center" },
  header: { marginBottom: 18 },
  title: { color: "#0B2036", fontSize: 28, fontWeight: "800", textAlign: "right" },
  subtitle: { color: "#667085", marginTop: 6, textAlign: "right" },
  card: { backgroundColor: "#fff", borderRadius: 20, padding: 18, marginBottom: 12, borderWidth: 1, borderColor: "#E7ECF2" },
  row: { flexDirection: "row", alignItems: "center", gap: 12 },
  invoiceNo: { color: "#0B2036", fontSize: 17, fontWeight: "800", textAlign: "right" },
  date: { color: "#667085", fontSize: 12, marginTop: 7, textAlign: "right" },
  invoiceIcon: { width: 48, height: 48, borderRadius: 15, backgroundColor: "#FFF3E9", alignItems: "center", justifyContent: "center" },
  totalRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 18, paddingTop: 14, borderTopWidth: 1, borderTopColor: "#EEF1F5" },
  total: { color: "#0B2036", fontSize: 18, fontWeight: "800" },
  status: { backgroundColor: "#E8F1FB", borderRadius: 99, paddingHorizontal: 10, paddingVertical: 5 },
  statusText: { color: "#0B2036", fontSize: 12, fontWeight: "700" },
  empty: { backgroundColor: "#fff", borderRadius: 20, padding: 30, alignItems: "center", borderWidth: 1, borderColor: "#E7ECF2" },
  emptyTitle: { color: "#0B2036", fontSize: 18, fontWeight: "800", marginTop: 10 },
  emptyText: { color: "#667085", marginTop: 7, textAlign: "center" },
} as const;
