import { FlatList, RefreshControl, Text, View } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { ScreenContainer } from "@/components/screen-container";
import { useApp } from "@/lib/app-context";

export default function ShipmentsScreen() {
  const { customer, shipments, loading, refreshing, refresh } = useApp();
  return (
    <ScreenContainer containerClassName="bg-[#F4F7FB]" className="px-5">
      <FlatList
        data={shipments}
        keyExtractor={(item) => item.id}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={refresh} tintColor="#E87528" />}
        contentContainerStyle={styles.list}
        ListHeaderComponent={<View style={styles.header}><Text style={styles.title}>شحنات {customer?.name || "العميل"}</Text><Text style={styles.subtitle}>تحديث مباشر من قاعدة بيانات AM Express</Text></View>}
        ListEmptyComponent={<View style={styles.empty}><Ionicons name={loading ? "hourglass-outline" : "cube-outline"} size={36} color="#E87528" /><Text style={styles.emptyTitle}>{loading ? "جاري التحميل" : "لا توجد شحنات مرتبطة"}</Text><Text style={styles.emptyText}>ستظهر هنا كل الشحنات المرتبطة بحسابك.</Text></View>}
        renderItem={({ item }) => (
          <View style={styles.card}>
            <View style={styles.row}><View style={{ flex: 1 }}><Text style={styles.tracking}>{item.tracking_no}</Text><Text style={styles.route}>{item.origin || "—"} → {item.destination || "—"}</Text></View><View style={styles.icon}><Ionicons name="boat-outline" color="#E87528" size={24} /></View></View>
            <View style={styles.divider} />
            <View style={styles.row}><Text style={styles.meta}>{new Date(item.created_at).toLocaleDateString("ar-EG")}</Text><View style={styles.status}><Text style={styles.statusText}>{item.status || "قيد المعالجة"}</Text></View></View>
            {item.history?.length ? <Text style={styles.history}>آخر تحديث: {item.history[item.history.length - 1]?.note || item.history[item.history.length - 1]?.status || "تم تحديث الحالة"}</Text> : null}
          </View>
        )}
      />
    </ScreenContainer>
  );
}

const styles = {
  list: { paddingTop: 20, paddingBottom: 30, maxWidth: 760, width: "100%", alignSelf: "center" },
  header: { marginBottom: 18 },
  title: { color: "#0B2036", fontSize: 28, fontWeight: "800", textAlign: "right" },
  subtitle: { color: "#667085", marginTop: 6, textAlign: "right" },
  card: { backgroundColor: "#fff", borderRadius: 20, padding: 18, marginBottom: 12, borderWidth: 1, borderColor: "#E7ECF2" },
  row: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", gap: 12 },
  tracking: { color: "#0B2036", fontSize: 17, fontWeight: "800", textAlign: "right" },
  route: { color: "#667085", marginTop: 7, textAlign: "right" },
  icon: { width: 48, height: 48, borderRadius: 15, backgroundColor: "#FFF3E9", alignItems: "center", justifyContent: "center" },
  divider: { height: 1, backgroundColor: "#EEF1F5", marginVertical: 14 },
  meta: { color: "#98A2B3", fontSize: 12 },
  status: { backgroundColor: "#E8F1FB", borderRadius: 99, paddingHorizontal: 10, paddingVertical: 5 },
  statusText: { color: "#0B2036", fontSize: 12, fontWeight: "700" },
  history: { color: "#667085", fontSize: 12, marginTop: 12, textAlign: "right" },
  empty: { backgroundColor: "#fff", borderRadius: 20, padding: 30, alignItems: "center", borderWidth: 1, borderColor: "#E7ECF2" },
  emptyTitle: { color: "#0B2036", fontSize: 18, fontWeight: "800", marginTop: 10 },
  emptyText: { color: "#667085", marginTop: 7, textAlign: "center" },
} as const;
