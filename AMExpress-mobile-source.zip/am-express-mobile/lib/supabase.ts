import AsyncStorage from "@react-native-async-storage/async-storage";
import { createClient } from "@supabase/supabase-js";

export const SUPABASE_URL = "https://nfjodguwkhvqauuijmie.supabase.co";
export const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_5rC_WDNfwa9fSeVRImWOQQ_U9UO7_kH";

const safeStorage = {
  getItem: async (key: string) => {
    if (typeof window === "undefined") return null;
    return AsyncStorage.getItem(key);
  },
  setItem: async (key: string, value: string) => {
    if (typeof window === "undefined") return;
    await AsyncStorage.setItem(key, value);
  },
  removeItem: async (key: string) => {
    if (typeof window === "undefined") return;
    await AsyncStorage.removeItem(key);
  },
};

export const supabase = createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
  auth: {
    storage: safeStorage,
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: false,
  },
});

export type Customer = {
  id: string;
  name: string;
  phone: string;
  email: string;
  address?: string;
};

export type Shipment = {
  id: string;
  tracking_no: string;
  customer_id: string;
  origin: string;
  destination: string;
  status: string;
  created_at: string;
  history?: Array<{ status?: string; date?: string; note?: string }>;
};

export type Invoice = {
  id: string;
  invoice_no: string;
  customer_id: string;
  customer_name: string;
  total: number;
  status: string;
  currency: string;
  issue_date: string;
  due_date?: string;
  items?: unknown[];
};

export type CustomerRole = "customer" | "staff" | "admin" | "unknown";

export function money(value: number, currency = "USD") {
  return `${currency} ${Number(value || 0).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}
