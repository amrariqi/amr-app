import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Session } from "@supabase/supabase-js";
import { supabase, type Customer, type CustomerRole, type Invoice, type Shipment } from "@/lib/supabase";

type AppContextValue = {
  session: Session | null;
  customer: Customer | null;
  role: CustomerRole;
  shipments: Shipment[];
  invoices: Invoice[];
  loading: boolean;
  refreshing: boolean;
  error: string;
  signInCustomer: (email: string, phone: string, password: string) => Promise<{ ok: boolean; message?: string }>;
  signOut: () => Promise<void>;
  refresh: () => Promise<void>;
};

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [customer, setCustomer] = useState<Customer | null>(null);
  const [role, setRole] = useState<CustomerRole>("unknown");
  const [shipments, setShipments] = useState<Shipment[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState("");

  const loadProfile = useCallback(async (activeSession: Session | null) => {
    if (!activeSession) {
      setCustomer(null);
      setRole("unknown");
      setShipments([]);
      setInvoices([]);
      return;
    }
    const { data: appUser, error: appUserError } = await supabase
      .from("app_users")
      .select("role,customer_id")
      .eq("id", activeSession.user.id)
      .maybeSingle();
    if (appUserError || !appUser) {
      setError("الحساب غير مرتبط بملف عميل في AM Express.");
      await supabase.auth.signOut();
      return;
    }
    const nextRole = (appUser.role || "unknown") as CustomerRole;
    setRole(nextRole);
    if (nextRole !== "customer" || !appUser.customer_id) {
      setCustomer(null);
      setShipments([]);
      setInvoices([]);
      setError(nextRole === "admin" || nextRole === "staff" ? "حساب الموظف موجود. سيتم تفعيل لوحة العمل الخاصة به في الإصدار التالي." : "لا يوجد ملف عميل مرتبط بهذا الحساب.");
      return;
    }
    const [customerResult, shipmentsResult, invoicesResult] = await Promise.all([
      supabase.from("customers").select("id,name,phone,email,address").eq("id", appUser.customer_id).maybeSingle(),
      supabase.from("shipments").select("id,tracking_no,customer_id,origin,destination,status,created_at,history").eq("customer_id", appUser.customer_id).order("created_at", { ascending: false }),
      supabase.from("invoices").select("id,invoice_no,customer_id,customer_name,total,status,currency,issue_date,due_date,items").eq("customer_id", appUser.customer_id).order("created_at", { ascending: false }),
    ]);
    if (customerResult.error) throw customerResult.error;
    if (shipmentsResult.error) throw shipmentsResult.error;
    if (invoicesResult.error) throw invoicesResult.error;
    setCustomer(customerResult.data as Customer | null);
    setShipments((shipmentsResult.data || []) as Shipment[]);
    setInvoices((invoicesResult.data || []) as Invoice[]);
    setError("");
  }, []);

  const refresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await loadProfile(session);
    } catch (refreshError) {
      setError(refreshError instanceof Error ? refreshError.message : "تعذر تحديث البيانات");
    } finally {
      setRefreshing(false);
    }
  }, [loadProfile, session]);

  useEffect(() => {
    let mounted = true;
    supabase.auth.getSession().then(async ({ data }) => {
      if (!mounted) return;
      setSession(data.session);
      try {
        await loadProfile(data.session);
      } catch (loadError) {
        setError(loadError instanceof Error ? loadError.message : "تعذر تحميل بيانات الحساب");
      } finally {
        if (mounted) setLoading(false);
      }
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, nextSession) => {
      setSession(nextSession);
      void loadProfile(nextSession).catch(() => setError("تعذر تحديث جلسة الحساب"));
    });
    return () => {
      mounted = false;
      listener.subscription.unsubscribe();
    };
  }, [loadProfile]);

  const signInCustomer = useCallback(async (email: string, phone: string, password: string) => {
    setError("");
    if (!email.trim() || !phone.trim() || !password) return { ok: false, message: "أدخل البريد ورقم الهاتف وكلمة المرور" };
    const { error: signInError } = await supabase.auth.signInWithPassword({ email: email.trim().toLowerCase(), password });
    if (signInError) return { ok: false, message: "بيانات الدخول غير صحيحة" };
    const { data: signedIn } = await supabase.auth.getSession();
    const activeSession = signedIn.session;
    if (!activeSession) return { ok: false, message: "تعذر إنشاء الجلسة" };
    const { data: appUser } = await supabase.from("app_users").select("role,customer_id").eq("id", activeSession.user.id).maybeSingle();
    if (!appUser || appUser.role !== "customer" || !appUser.customer_id) {
      await supabase.auth.signOut();
      return { ok: false, message: "هذا الحساب غير مخصص لبوابة العملاء" };
    }
    const { data: customerRow } = await supabase.from("customers").select("id,name,phone,email").eq("id", appUser.customer_id).maybeSingle();
    const normalizedPhone = phone.replace(/[\s()-]/g, "");
    if (!customerRow || (customerRow.phone || "").replace(/[\s()-]/g, "") !== normalizedPhone || (customerRow.email || "").toLowerCase() !== email.trim().toLowerCase()) {
      await supabase.auth.signOut();
      return { ok: false, message: "البريد أو رقم الهاتف لا يطابقان ملف العميل" };
    }
    await loadProfile(activeSession);
    return { ok: true };
  }, [loadProfile]);

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setSession(null);
    setCustomer(null);
    setShipments([]);
    setInvoices([]);
    setRole("unknown");
  }, []);

  const value = useMemo(() => ({ session, customer, role, shipments, invoices, loading, refreshing, error, signInCustomer, signOut, refresh }), [session, customer, role, shipments, invoices, loading, refreshing, error, signInCustomer, signOut, refresh]);
  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp() {
  const value = useContext(AppContext);
  if (!value) throw new Error("useApp must be used inside AppProvider");
  return value;
}
