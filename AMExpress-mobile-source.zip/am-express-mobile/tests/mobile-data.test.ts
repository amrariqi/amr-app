import { describe, expect, it } from "vitest";
import { money } from "../lib/supabase";

describe("AM Express mobile data helpers", () => {
  it("formats invoice amounts with the invoice currency", () => {
    expect(money(1250.5, "USD")).toBe("USD 1,250.50");
    expect(money(0, "SAR")).toBe("SAR 0.00");
  });

  it("does not expose a contact field in the mobile shipment view model", () => {
    const shipment = { tracking_no: "AMX-100", origin: "Dubai", destination: "Jeddah", status: "قيد النقل" };
    expect(shipment).not.toHaveProperty("phone");
    expect(shipment).not.toHaveProperty("email");
  });
});
