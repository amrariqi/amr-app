import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_stripe/flutter_stripe.dart';
import 'package:provider/provider.dart';
import 'config/backend_config.dart';
import 'services/providers.dart';
import 'screens/root_shell.dart';
import 'theme/app_theme.dart';

// الشاشة البيضاء الفارغة عند فتح تطبيق Flutter (في نسخة release تحديدًا)
// سببها المعتاد: خطأ غير متوقَع يحدث قبل ()runApp فيمنع ظهور أي واجهة
// إطلاقًا، ولا تظهر رسالة الخطأ لأن وضع release لا يعرضها كوضع debug.
// لذلك هنا: (1) نلف تهيئة Stripe بـ try/catch حتى لا يمنع أي عطل فيها
// فتح التطبيق كاملًا، و(2) نلتقط أي خطأ آخر غير متوقع ونعرضه على الشاشة
// بدل تركها بيضاء — هذا يسمح لاحقًا بمعرفة سبب أي عطل من لقطة شاشة فقط.
Future<void> main() async {
  runZonedGuarded(() async {
    WidgetsFlutterBinding.ensureInitialized();

    FlutterError.onError = (FlutterErrorDetails details) {
      FlutterError.presentError(details);
      debugPrint('FlutterError: ${details.exceptionAsString()}');
    };
    ErrorWidget.builder = (FlutterErrorDetails details) => _ErrorScreen(details.exceptionAsString());

    try {
      // تهيئة Stripe بالمفتاح العام فقط — المفتاح السري يبقى على الخادم
      // (راجع lib/services/payment_gateway.dart وlib/config/backend_config.dart).
      Stripe.publishableKey = BackendConfig.stripePublishableKey;
      await Stripe.instance.applySettings();
    } catch (e, st) {
      // فشل تهيئة Stripe يجب ألا يمنع فتح التطبيق — فقط الدفع بالبطاقة
      // سيتعطل حينها ويظهر رسالة خطأ واضحة عند استخدامه تحديدًا.
      debugPrint('تعذّرت تهيئة Stripe: $e\n$st');
    }

    runApp(const ShopPosApp());
  }, (error, stack) {
    debugPrint('خطأ غير متوقع خارج شجرة الواجهة: $error\n$stack');
    runApp(_ErrorApp(error.toString()));
  });
}

/// تطبيق بديل مصغّر يُعرض فقط إذا فشل تشغيل التطبيق الحقيقي بالكامل —
/// يستبدل الشاشة البيضاء الصامتة برسالة يمكن أخذ لقطة شاشة لها.
class _ErrorApp extends StatelessWidget {
  final String message;
  const _ErrorApp(this.message);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Directionality(
        textDirection: TextDirection.rtl,
        child: _ErrorScreen(message),
      ),
    );
  }
}

class _ErrorScreen extends StatelessWidget {
  final String message;
  const _ErrorScreen(this.message);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(Icons.error_outline, color: Colors.red, size: 48),
              const SizedBox(height: 16),
              const Text(
                'حدث خطأ غير متوقع عند تشغيل التطبيق',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 12),
              Text(
                message,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 13, color: Colors.black54),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class ShopPosApp extends StatelessWidget {
  const ShopPosApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => InventoryProvider()..loadProducts()),
        ChangeNotifierProvider(create: (_) => CartProvider()),
      ],
      child: MaterialApp(
        title: 'نظام نقاط البيع',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.light,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar'), Locale('en')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        builder: (context, child) {
          return Directionality(
            textDirection: TextDirection.rtl,
            child: child ?? const SizedBox.shrink(),
          );
        },
        home: const RootShell(),
      ),
    );
  }
}
