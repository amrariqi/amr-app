import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../models/models.dart';
import '../services/providers.dart';
import '../theme/app_theme.dart';
import '../widgets/empty_state.dart';
import 'product_form_screen.dart';

class InventoryScreen extends StatelessWidget {
  const InventoryScreen({super.key});

  Future<void> _confirmDelete(BuildContext context, Product product) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('حذف المنتج؟'),
        content: Text('سيتم حذف "${product.name}" نهائيًا من المخزون.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('إلغاء'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(backgroundColor: AppColors.danger),
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('حذف'),
          ),
        ],
      ),
    );
    if (confirmed == true && context.mounted) {
      await context.read<InventoryProvider>().deleteProduct(product.id!);
    }
  }

  @override
  Widget build(BuildContext context) {
    final inventory = context.watch<InventoryProvider>();
    final formatter = NumberFormat.currency(locale: 'en', name: AppConfig.currencyCode, decimalDigits: 2);

    return Scaffold(
      appBar: AppBar(title: const Text('المخزون')),
      floatingActionButton: FloatingActionButton.extended(
        backgroundColor: AppColors.primary,
        foregroundColor: Colors.white,
        onPressed: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const ProductFormScreen()),
        ),
        icon: const Icon(Icons.add),
        label: const Text('منتج جديد'),
      ),
      body: inventory.products.isEmpty
          ? EmptyState(
              icon: Icons.inventory_2_outlined,
              title: 'لا توجد منتجات بعد',
              message: 'أضف أول منتج للبدء في البيع.',
              actionLabel: 'إضافة منتج',
              onAction: () => Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const ProductFormScreen()),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 96),
              itemCount: inventory.products.length,
              separatorBuilder: (_, __) => const SizedBox(height: 10),
              itemBuilder: (context, index) {
                final product = inventory.products[index];
                final lowStock = product.stockQuantity <= product.lowStockThreshold;
                return Container(
                  padding: const EdgeInsets.all(12),
                  decoration: AppDecorations.card(radius: 16),
                  child: Row(
                    children: [
                      Container(
                        width: 40,
                        height: 40,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: AppColors.primary.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          product.name.isNotEmpty ? product.name.substring(0, 1) : '?',
                          style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(product.name, style: const TextStyle(fontWeight: FontWeight.w700)),
                            const SizedBox(height: 4),
                            Row(
                              children: [
                                Icon(
                                  lowStock ? Icons.warning : Icons.inventory_2_outlined,
                                  size: 13,
                                  color: lowStock ? AppColors.danger : AppColors.textSecondary,
                                ),
                                const SizedBox(width: 4),
                                Text(
                                  'الكمية: ${product.stockQuantity}',
                                  style: TextStyle(
                                    color: lowStock ? AppColors.danger : AppColors.textSecondary,
                                    fontSize: 12,
                                    fontWeight: lowStock ? FontWeight.w700 : FontWeight.w400,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Text(
                        formatter.format(product.price),
                        style: const TextStyle(fontWeight: FontWeight.w800, color: AppColors.primary),
                      ),
                      const SizedBox(width: 4),
                      _IconAction(
                        icon: Icons.edit_outlined,
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => ProductFormScreen(existing: product)),
                        ),
                      ),
                      _IconAction(
                        icon: Icons.delete_outline,
                        color: AppColors.danger,
                        onTap: () => _confirmDelete(context, product),
                      ),
                    ],
                  ),
                );
              },
            ),
    );
  }
}

class _IconAction extends StatelessWidget {
  final IconData icon;
  final Color? color;
  final VoidCallback onTap;
  const _IconAction({required this.icon, required this.onTap, this.color});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 4),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: AppColors.surfaceAlt,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Icon(icon, size: 18, color: color ?? AppColors.textSecondary),
        ),
      ),
    );
  }
}
