import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../db/database_helper.dart';
import '../services/providers.dart';
import '../theme/app_theme.dart';

class DashboardScreen extends StatefulWidget {
  final VoidCallback onStartSale;
  final VoidCallback onOpenInventory;
  final VoidCallback onOpenReports;

  const DashboardScreen({
    super.key,
    required this.onStartSale,
    required this.onOpenInventory,
    required this.onOpenReports,
  });

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

// أسماء الأيام والأشهر مكتوبة يدويًا بدل الاعتماد على DateFormat(..., 'ar')
// من حزمة intl، لأن استخدام أي لغة غير الافتراضية معها يتطلب استدعاء
// initializeDateFormatting() أولًا في main() — وإغفال ذلك يرمي استثناءً عند
// أول بناء لهذه الشاشة (تمامًا كنوع الخطأ الذي تسبّب بالشاشة البيضاء سابقًا).
// هذا الأسلوب لا يحتاج أي تهيئة ولا يمكن أن يفشل.
const _weekdays = ['الاثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد'];
const _months = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر',
];

class _DashboardScreenState extends State<DashboardScreen> {
  double _todayTotal = 0;
  int _todayCount = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadToday();
  }

  Future<void> _loadToday() async {
    final now = DateTime.now();
    final start = DateTime(now.year, now.month, now.day);
    final end = start.add(const Duration(days: 1));
    final sales = await DatabaseHelper.instance.getSales(from: start, to: end);
    if (!mounted) return;
    setState(() {
      _todayTotal = sales.fold(0.0, (sum, s) => sum + s.total);
      _todayCount = sales.length;
      _loading = false;
    });
  }

  String get _greeting => DateTime.now().hour < 12 ? 'صباح الخير' : 'مساء الخير';

  String get _todayLabel {
    final now = DateTime.now();
    return '${_weekdays[now.weekday - 1]}، ${now.day} ${_months[now.month - 1]}';
  }

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat.currency(locale: 'en', name: AppConfig.currencyCode, decimalDigits: 2);
    final inventory = context.watch<InventoryProvider>();
    final lowStockCount =
        inventory.products.where((p) => p.stockQuantity <= p.lowStockThreshold).length;

    return Scaffold(
      appBar: AppBar(title: const Text('الرئيسية')),
      body: RefreshIndicator(
        onRefresh: _loadToday,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(_greeting, style: const TextStyle(fontSize: 15, color: AppColors.textSecondary, fontWeight: FontWeight.w600)),
            const SizedBox(height: 2),
            Text(_todayLabel, style: const TextStyle(fontSize: 13, color: AppColors.textSecondary)),
            const SizedBox(height: 16),
            Container(
              padding: const EdgeInsets.all(22),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topRight,
                  end: Alignment.bottomLeft,
                  colors: [AppColors.primary, AppColors.primaryDark],
                ),
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(color: AppColors.primary.withOpacity(0.28), blurRadius: 20, offset: const Offset(0, 10)),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: const [
                      Icon(Icons.trending_up, color: Colors.white70, size: 18),
                      SizedBox(width: 6),
                      Text('مبيعات اليوم', style: TextStyle(color: Colors.white70, fontSize: 14, fontWeight: FontWeight.w600)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  _loading
                      ? const SizedBox(
                          height: 32,
                          width: 32,
                          child: CircularProgressIndicator(color: Colors.white, strokeWidth: 3),
                        )
                      : Text(
                          formatter.format(_todayTotal),
                          style: const TextStyle(color: Colors.white, fontSize: 34, fontWeight: FontWeight.w800),
                        ),
                  const SizedBox(height: 14),
                  Container(width: double.infinity, height: 1, color: Colors.white.withOpacity(0.18)),
                  const SizedBox(height: 14),
                  Row(
                    children: [
                      const Icon(Icons.receipt_long_outlined, color: Colors.white70, size: 16),
                      const SizedBox(width: 6),
                      Text(
                        _loading ? '...' : '$_todayCount عملية بيع اليوم',
                        style: const TextStyle(color: Colors.white70, fontSize: 13, fontWeight: FontWeight.w500),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            if (lowStockCount > 0) ...[
              const SizedBox(height: 14),
              InkWell(
                onTap: widget.onOpenInventory,
                borderRadius: BorderRadius.circular(16),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.danger.withOpacity(0.08),
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: AppColors.danger.withOpacity(0.25)),
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.warning_amber_rounded, color: AppColors.danger),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Text(
                          '$lowStockCount منتج بحاجة لإعادة تخزين',
                          style: const TextStyle(color: AppColors.danger, fontWeight: FontWeight.w700, fontSize: 13),
                        ),
                      ),
                      const Icon(Icons.chevron_left, color: AppColors.danger),
                    ],
                  ),
                ),
              ),
            ],
            const SizedBox(height: 24),
            const Text('اختصارات سريعة', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w700, color: AppColors.textSecondary)),
            const SizedBox(height: 12),
            _QuickAction(
              icon: Icons.point_of_sale,
              label: 'بيع جديد',
              subtitle: 'ابدأ عملية بيع جديدة',
              onTap: widget.onStartSale,
            ),
            const SizedBox(height: 10),
            _QuickAction(
              icon: Icons.inventory_2,
              label: 'إدارة المخزون',
              subtitle: 'أضف أو عدّل المنتجات',
              onTap: widget.onOpenInventory,
            ),
            const SizedBox(height: 10),
            _QuickAction(
              icon: Icons.bar_chart,
              label: 'التقارير',
              subtitle: 'راجع كل عمليات البيع',
              onTap: widget.onOpenReports,
            ),
          ],
        ),
      ),
    );
  }
}

class _QuickAction extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final VoidCallback onTap;

  const _QuickAction({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: AppDecorations.card(),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: AppColors.primary),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                ],
              ),
            ),
            const Icon(Icons.chevron_left, color: AppColors.textSecondary),
          ],
        ),
      ),
    );
  }
}
