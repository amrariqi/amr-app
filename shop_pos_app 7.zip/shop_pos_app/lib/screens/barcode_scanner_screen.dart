import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import '../theme/app_theme.dart';

/// شاشة مسح باركود عامة يُعاد استخدامها من أكثر من مكان (البحث عن منتج
/// أثناء البيع في PosScreen، وتعبئة حقل الباركود في ProductFormScreen) —
/// تُعيد النص الممسوح كسلسلة نصية واحدة عبر Navigator.pop، بنفس نمط
/// الإرجاع المُتَّبع في ManualApprovalScreen، أو null إن أغلق المستخدم
/// الشاشة بدون مسح شيء.
///
/// حزمة الكاميرا (mobile_scanner) تتولى طلب إذن الكاميرا وعرض رسالة رفض
/// الإذن بنفسها داخليًا — لا حاجة لأي إعداد يدوي إضافي في AndroidManifest
/// من جهتنا (على عكس تعديل MainActivity الذي احتجناه فعلًا لـ Stripe).
class BarcodeScannerScreen extends StatefulWidget {
  const BarcodeScannerScreen({super.key});

  @override
  State<BarcodeScannerScreen> createState() => _BarcodeScannerScreenState();
}

class _BarcodeScannerScreenState extends State<BarcodeScannerScreen> {
  // الكاميرا قد تُرسِل عدة نتائج مسح متتالية قبل أن تُغلَق الشاشة فعليًا بعد
  // أول Navigator.pop — هذا العلم يمنع محاولة إغلاق الشاشة أكثر من مرة.
  bool _handled = false;

  void _onDetect(BarcodeCapture capture) {
    if (_handled) return;
    final barcodes = capture.barcodes;
    if (barcodes.isEmpty) return;

    final value = barcodes.first.rawValue;
    if (value == null || value.isEmpty) return;

    _handled = true;
    Navigator.of(context).pop(value);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.black,
        foregroundColor: Colors.white,
        elevation: 0,
        leading: const BackButton(),
        title: const Text('امسح الباركود'),
      ),
      body: Stack(
        alignment: Alignment.center,
        children: [
          MobileScanner(onDetect: _onDetect),
          // إطار إرشادي فقط لتوضيح أين يجب توجيه الكاميرا — بلا أي تأثير
          // على المسح نفسه.
          Container(
            width: 240,
            height: 140,
            decoration: BoxDecoration(
              border: Border.all(color: AppColors.glow, width: 2.5),
              borderRadius: BorderRadius.circular(16),
            ),
          ),
          Positioned(
            bottom: 36,
            left: 24,
            right: 24,
            child: Text(
              'وجّه الكاميرا نحو باركود المنتج',
              textAlign: TextAlign.center,
              style: TextStyle(color: Colors.white.withOpacity(0.85), fontSize: 13),
            ),
          ),
        ],
      ),
    );
  }
}
