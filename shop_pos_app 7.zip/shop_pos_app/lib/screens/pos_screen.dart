import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../models/models.dart';
import '../services/providers.dart';
import '../theme/app_theme.dart';
import '../widgets/empty_state.dart';
import 'barcode_scanner_screen.dart';
import 'payment_method_sheet.dart';

class PosScreen extends StatefulWidget {
  const PosScreen({super.key});

  @override
  State<PosScreen> createState() => _PosScreenState();
}

class _PosScreenState extends State<PosScreen> {
  String _query = '';

  // يفتح شاشة المسح (barcode_scanner_screen.dart)، وعند الحصول على نص، يبحث
  // عن منتج بنفس الباركود بين المنتجات المُحمَّلة بالفعل في الذاكرة (بلا أي
  // استعلام إضافي لقاعدة البيانات) ويضيفه للسلة مباشرة إن وُجد.
  Future<void> _scanBarcode() async {
    final code = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => const BarcodeScannerScreen()),
    );
    if (code == null || !mounted) return;

    final inventory = context.read<InventoryProvider>();
    Product? match;
    for (final p in inventory.products) {
      if (p.barcode == code) {
        match = p;
        break;
      }
    }

    if (match == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('لم يتم العثور على منتج بهذا الباركود')),
      );
      return;
    }
    if (match.stockQuantity <= 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${match.name} — نفدت الكمية')),
      );
      return;
    }
    context.read<CartProvider>().addProduct(match);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('أُضيف: ${match.name}'), duration: const Duration(seconds: 1)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final inventory = context.watch<InventoryProvider>();
    final cart = context.watch<CartProvider>();
    final formatter = NumberFormat.currency(locale: 'en', name: AppConfig.currencyCode, decimalDigits: 2);

    final products = inventory.products
        .where((p) => p.name.toLowerCase().contains(_query.toLowerCase()))
        .toList();

    return Scaffold(
      appBar: AppBar(title: const Text('بيع جديد')),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 8, 16, 8),
            child: TextField(
              decoration: InputDecoration(
                hintText: 'ابحث عن منتج...',
                prefixIcon: const Icon(Icons.search),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.qr_code_scanner),
                  tooltip: 'مسح باركود',
                  onPressed: _scanBarcode,
                ),
              ),
              onChanged: (value) => setState(() => _query = value),
            ),
          ),
          Expanded(
            child: products.isEmpty
                ? const EmptyState(
                    icon: Icons.inventory_2_outlined,
                    title: 'لا توجد منتجات مطابقة',
                    message: 'أضف منتجات من شاشة المخزون أولًا.',
                  )
                : GridView.builder(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 16),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      mainAxisSpacing: 12,
                      crossAxisSpacing: 12,
                      childAspectRatio: 1.25,
                    ),
                    itemCount: products.length,
                    itemBuilder: (context, index) {
                      final product = products[index];
                      final outOfStock = product.stockQuantity <= 0;
                      return InkWell(
                        onTap: outOfStock ? null : () => cart.addProduct(product),
                        borderRadius: BorderRadius.circular(16),
                        child: Container(
                          padding: const EdgeInsets.all(14),
                          decoration: AppDecorations.card(
                            radius: 16,
                            color: outOfStock ? AppColors.surfaceAlt : AppColors.surface,
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Container(
                                width: 36,
                                height: 36,
                                alignment: Alignment.center,
                                decoration: BoxDecoration(
                                  color: outOfStock ? AppColors.border : AppColors.primary.withOpacity(0.1),
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                child: Text(
                                  product.name.isNotEmpty ? product.name.substring(0, 1) : '?',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    color: outOfStock ? AppColors.textSecondary : AppColors.primary,
                                  ),
                                ),
                              ),
                              const SizedBox(height: 10),
                              Text(
                                product.name,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                outOfStock ? 'نفدت الكمية' : formatter.format(product.price),
                                style: TextStyle(
                                  color: outOfStock ? AppColors.danger : AppColors.primary,
                                  fontWeight: FontWeight.w800,
                                  fontSize: 15,
                                ),
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),
          if (!cart.isEmpty) _CartBar(formatter: formatter),
        ],
      ),
    );
  }
}

class _CartBar extends StatelessWidget {
  final NumberFormat formatter;
  const _CartBar({required this.formatter});

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();

    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 12),
      decoration: const BoxDecoration(
        color: AppColors.surface,
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
        boxShadow: [BoxShadow(color: AppColors.shadow, blurRadius: 20, offset: Offset(0, -6))],
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            SizedBox(
              height: 92,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: cart.lines.length,
                itemBuilder: (context, index) {
                  final line = cart.lines[index];
                  return Container(
                    width: 148,
                    margin: const EdgeInsets.only(left: 8),
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppColors.surfaceAlt,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          line.product.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13),
                        ),
                        const Spacer(),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            _StepperButton(
                              icon: Icons.remove,
                              onTap: () => cart.setQuantity(line.product.id!, line.quantity - 1),
                            ),
                            Text('${line.quantity}', style: const TextStyle(fontWeight: FontWeight.w700)),
                            _StepperButton(
                              icon: Icons.add,
                              onTap: () => cart.setQuantity(line.product.id!, line.quantity + 1),
                            ),
                          ],
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Text('الإجمالي', style: Theme.of(context).textTheme.titleMedium),
                const Spacer(),
                Text(
                  formatter.format(cart.total),
                  style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: AppColors.primary),
                ),
              ],
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: () => showModalBottomSheet(
                  context: context,
                  isScrollControlled: true,
                  backgroundColor: Colors.transparent,
                  builder: (_) => const PaymentMethodSheet(),
                ),
                icon: const Icon(Icons.check_circle_outline),
                label: const Text('إتمام البيع'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _StepperButton extends StatelessWidget {
  final IconData icon;
  final VoidCallback onTap;
  const _StepperButton({required this.icon, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        width: 26,
        height: 26,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: AppColors.primary.withOpacity(0.12),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Icon(icon, size: 15, color: AppColors.primary),
      ),
    );
  }
}
