import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/models.dart';
import '../services/providers.dart';
import 'barcode_scanner_screen.dart';

class ProductFormScreen extends StatefulWidget {
  final Product? existing;
  const ProductFormScreen({super.key, this.existing});

  @override
  State<ProductFormScreen> createState() => _ProductFormScreenState();
}

class _ProductFormScreenState extends State<ProductFormScreen> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _priceController;
  late final TextEditingController _stockController;
  late final TextEditingController _categoryController;
  late final TextEditingController _barcodeController;
  late final TextEditingController _lowStockController;

  @override
  void initState() {
    super.initState();
    final p = widget.existing;
    _nameController = TextEditingController(text: p?.name ?? '');
    _priceController = TextEditingController(text: p != null ? p.price.toString() : '');
    _stockController = TextEditingController(text: p != null ? p.stockQuantity.toString() : '');
    _categoryController = TextEditingController(text: p?.category ?? '');
    _barcodeController = TextEditingController(text: p?.barcode ?? '');
    _lowStockController = TextEditingController(text: (p?.lowStockThreshold ?? 5).toString());
  }

  @override
  void dispose() {
    _nameController.dispose();
    _priceController.dispose();
    _stockController.dispose();
    _categoryController.dispose();
    _barcodeController.dispose();
    _lowStockController.dispose();
    super.dispose();
  }

  // يفتح شاشة المسح نفسها المُستخدَمة في شاشة البيع (barcode_scanner_screen)
  // لتعبئة حقل الباركود مباشرة، بدل الاضطرار لكتابته يدويًا من طباعة المنتج.
  Future<void> _scanIntoBarcodeField() async {
    final code = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => const BarcodeScannerScreen()),
    );
    if (code != null && mounted) {
      setState(() => _barcodeController.text = code);
    }
  }

  Future<void> _save() async {
    if (!_formKey.currentState!.validate()) return;

    final product = Product(
      id: widget.existing?.id,
      name: _nameController.text.trim(),
      price: double.parse(_priceController.text.trim()),
      stockQuantity: int.parse(_stockController.text.trim()),
      category: _categoryController.text.trim().isEmpty ? null : _categoryController.text.trim(),
      barcode: _barcodeController.text.trim().isEmpty ? null : _barcodeController.text.trim(),
      // الحقل اختياري ويُقبَل فارغًا (يُستخدَم الافتراضي 5 حينها) — التحقق في
      // validator أدناه يمنع الوصول لهذه النقطة أصلًا بقيمة غير رقمية.
      lowStockThreshold: _lowStockController.text.trim().isEmpty
          ? 5
          : int.parse(_lowStockController.text.trim()),
    );

    final inventory = context.read<InventoryProvider>();
    if (widget.existing == null) {
      await inventory.addProduct(product);
    } else {
      await inventory.updateProduct(product);
    }

    if (!mounted) return;
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final isEditing = widget.existing != null;
    return Scaffold(
      appBar: AppBar(title: Text(isEditing ? 'تعديل المنتج' : 'منتج جديد')),
      body: Form(
        key: _formKey,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            TextFormField(
              controller: _nameController,
              decoration: const InputDecoration(
                labelText: 'اسم المنتج',
                prefixIcon: Icon(Icons.shopping_bag),
              ),
              validator: (value) => (value == null || value.trim().isEmpty) ? 'مطلوب' : null,
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _priceController,
              decoration: const InputDecoration(
                labelText: 'السعر',
                prefixIcon: Icon(Icons.sell),
              ),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              validator: (value) {
                if (value == null || value.trim().isEmpty) return 'مطلوب';
                if (double.tryParse(value.trim()) == null) return 'رقم غير صحيح';
                return null;
              },
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _stockController,
              decoration: const InputDecoration(
                labelText: 'الكمية المتوفرة',
                prefixIcon: Icon(Icons.numbers),
              ),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value == null || value.trim().isEmpty) return 'مطلوب';
                if (int.tryParse(value.trim()) == null) return 'رقم غير صحيح';
                return null;
              },
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _categoryController,
              decoration: const InputDecoration(
                labelText: 'التصنيف (اختياري)',
                prefixIcon: Icon(Icons.category),
              ),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _barcodeController,
              decoration: InputDecoration(
                labelText: 'الباركود (اختياري)',
                prefixIcon: const Icon(Icons.qr_code),
                suffixIcon: IconButton(
                  icon: const Icon(Icons.qr_code_scanner),
                  tooltip: 'مسح بالكاميرا',
                  onPressed: _scanIntoBarcodeField,
                ),
              ),
            ),
            const SizedBox(height: 12),
            TextFormField(
              controller: _lowStockController,
              decoration: const InputDecoration(
                labelText: 'تنبيه عند وصول الكمية إلى (افتراضي 5)',
                prefixIcon: Icon(Icons.warning_amber_outlined),
              ),
              keyboardType: TextInputType.number,
              validator: (value) {
                if (value == null || value.trim().isEmpty) return null; // اختياري
                final parsed = int.tryParse(value.trim());
                if (parsed == null || parsed < 0) return 'رقم غير صحيح';
                return null;
              },
            ),
            const SizedBox(height: 24),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: _save,
                icon: const Icon(Icons.check),
                label: const Text('حفظ'),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
