import 'dart:async';

import 'package:flutter/material.dart';
import 'package:intl/intl.dart' hide TextDirection;
import 'package:provider/provider.dart';
import 'package:share_plus/share_plus.dart';
import '../db/database_helper.dart';
import '../models/models.dart';
import '../services/payment_gateway.dart';
import '../services/providers.dart';
import '../services/sales_sync_service.dart';
import '../theme/app_theme.dart';
import '../utils/uuid.dart';
import 'manual_approval_screen.dart';

class PaymentMethodSheet extends StatefulWidget {
  const PaymentMethodSheet({super.key});

  @override
  State<PaymentMethodSheet> createState() => _PaymentMethodSheetState();
}

class _PaymentMethodSheetState extends State<PaymentMethodSheet> {
  bool _processing = false;

  Future<void> _pay(POSPaymentMethod method, {String? manualNote}) async {
    final cart = context.read<CartProvider>();
    setState(() => _processing = true);

    final gateway = gatewayFor(method);
    final result = await gateway.charge(amount: cart.total, note: manualNote);

    if (!mounted) return;

    if (!result.success) {
      setState(() => _processing = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(result.errorMessage ?? 'تعذّر إتمام الدفع')),
      );
      return;
    }

    final sale = Sale(
      clientUuid: generateUuidV4(),
      createdAt: DateTime.now(),
      total: cart.total,
      paymentMethod: method,
      gatewayReference: result.reference,
      items: cart.lines
          .map((line) => SaleItem(
                productId: line.product.id!,
                productName: line.product.name,
                unitPrice: line.product.price,
                quantity: line.quantity,
              ))
          .toList(),
    );

    // يُبنى نص الإيصال الآن، من بيانات sale نفسها — قبل تفريغ السلة أو إغلاق
    // هذه الشاشة — حتى يبقى جاهزًا لزر "مشاركة الإيصال" في رسالة النجاح
    // بالأسفل بغض النظر عن أي تغيير لاحق في حالة الواجهة.
    final receiptText = _buildReceiptText(sale);

    final saleId = await DatabaseHelper.instance.insertSale(sale);

    // محاولة رفع نسخة من العملية إلى Supabase كنسخة احتياطية/لتقارير
    // موحّدة — لا تُنتظَر ولا تمنع إتمام البيع أبدًا. إن فشلت (لا إنترنت
    // مثلًا) تبقى العملية محفوظة محليًا وتُعاد محاولتها لاحقًا تلقائيًا
    // (راجع main.dart وSalesSyncService.syncPending).
    unawaited(SalesSyncService.pushSale(sale.copyWith(id: saleId)));

    if (!mounted) return;
    cart.clear();
    await context.read<InventoryProvider>().loadProducts();

    if (!mounted) return;
    Navigator.of(context).pop();
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: const Text('تم إتمام البيع بنجاح'),
        action: SnackBarAction(
          label: 'مشاركة الإيصال',
          // مشاركة نصية بسيطة عبر واجهة النظام القياسية (واتساب/رسالة
          // نصية/بريد/أي تطبيق آخر مثبَّت لدى الكاشير) — وليس إرسالًا تلقائيًا
          // عبر أي واجهة برمجية خاصة بواتساب، والتي تحتاج حسابًا واعتمادًا
          // منفصلين تمامًا لا علاقة لهما بهذا التطبيق.
          onPressed: () => SharePlus.instance.share(
            ShareParams(text: receiptText, subject: 'إيصال الشراء — ${AppConfig.shopName}'),
          ),
        ),
      ),
    );
  }

  // نص إيصال بسيط وقابل للمشاركة عبر أي تطبيق — راجع _pay أعلاه لمتى يُبنى
  // بالضبط (قبل تفريغ السلة، من بيانات sale المُخزَّنة فعليًا لا سلة العرض).
  String _buildReceiptText(Sale sale) {
    final formatter = NumberFormat.currency(locale: 'en', name: AppConfig.currencyCode, decimalDigits: 2);
    final dateFormatter = DateFormat('yyyy/MM/dd – HH:mm');

    final buffer = StringBuffer()
      ..writeln(AppConfig.shopName)
      ..writeln(dateFormatter.format(sale.createdAt))
      ..writeln('――――――――――――――――');
    for (final item in sale.items) {
      buffer.writeln('${item.productName} × ${item.quantity}  —  ${formatter.format(item.lineTotal)}');
    }
    buffer
      ..writeln('――――――――――――――――')
      ..writeln('الإجمالي: ${formatter.format(sale.total)}')
      ..writeln('طريقة الدفع: ${sale.paymentMethod.label}');
    if (sale.gatewayReference != null) {
      buffer.writeln('المرجع: ${sale.gatewayReference}');
    }
    return buffer.toString();
  }

  // يفتح شاشة "التفويض الهاتفي" الكاملة (تصميم داكن مخصّص لهذه اللحظة فقط
  // — راجع manual_approval_screen.dart لتفاصيل الحقول والتحقق)، وعند
  // التأكيد يتابع البيع بنفس مسار _pay المعتاد بالنص الذي أعادته الشاشة
  // (أو يُلغي بصمت إن رجع الكاشير بدون تأكيد).
  Future<void> _payWithManualApproval() async {
    final cart = context.read<CartProvider>();
    final note = await Navigator.of(context).push<String>(
      MaterialPageRoute(builder: (_) => ManualApprovalScreen(amount: cart.total)),
    );

    if (note == null) return; // ألغى الكاشير
    if (!mounted) return;
    await _pay(POSPaymentMethod.manualApproval, manualNote: note);
  }

  @override
  Widget build(BuildContext context) {
    final cart = context.watch<CartProvider>();
    final formatter = NumberFormat.currency(locale: 'en', name: AppConfig.currencyCode, decimalDigits: 2);

    return Container(
      decoration: const BoxDecoration(
        color: AppColors.background,
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 20),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(color: AppColors.border, borderRadius: BorderRadius.circular(4)),
              ),
            ),
            const SizedBox(height: 18),
            const Text('اختر طريقة الدفع', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 4),
            Text(
              'المبلغ الإجمالي ${formatter.format(cart.total)}',
              style: const TextStyle(fontSize: 13, color: AppColors.textSecondary),
            ),
            const SizedBox(height: 18),
            if (_processing)
              const Padding(
                padding: EdgeInsets.symmetric(vertical: 24),
                child: Center(child: CircularProgressIndicator()),
              )
            else ...[
              _MethodTile(
                icon: Icons.payments_outlined,
                label: 'نقدًا',
                subtitle: 'دفع فوري بدون اتصال بالإنترنت',
                onTap: () => _pay(POSPaymentMethod.cash),
              ),
              const SizedBox(height: 10),
              _MethodTile(
                icon: Icons.credit_card,
                label: 'بطاقة',
                subtitle: 'عبر Stripe — آمن ومشفّر بالكامل',
                onTap: () => _pay(POSPaymentMethod.card),
              ),
              const SizedBox(height: 10),
              _MethodTile(
                icon: Icons.account_balance_wallet_outlined,
                label: 'محفظة إلكترونية',
                subtitle: 'تحويل بنكي أو محفظة محلية',
                onTap: () => _pay(POSPaymentMethod.wallet),
              ),
              const SizedBox(height: 10),
              _MethodTile(
                icon: Icons.phone_forwarded_outlined,
                label: 'موافقة هاتفية',
                subtitle: 'تأكيد يدوي عبر اتصال البنك',
                onTap: _payWithManualApproval,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _MethodTile extends StatelessWidget {
  final IconData icon;
  final String label;
  final String subtitle;
  final VoidCallback onTap;

  const _MethodTile({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: AppDecorations.card(radius: 16),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppColors.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: AppColors.primary),
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(label, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
                  const SizedBox(height: 2),
                  Text(subtitle, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
                ],
              ),
            ),
            const Icon(Icons.chevron_left, color: AppColors.textSecondary),
          ],
        ),
      ),
    );
  }
}
