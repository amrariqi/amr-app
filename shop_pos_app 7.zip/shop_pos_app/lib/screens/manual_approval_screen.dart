import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:intl/intl.dart' hide TextDirection;
import '../theme/app_theme.dart';

/// شاشة "تفويض هاتفي" لعملية بطاقة تُسجَّل يدويًا — تُستخدَم بعد الاتصال
/// بخط التفويض الصوتي للبنك (أو عند ضعف الاتصال بالإنترنت) وإملاء رمز
/// الموافقة هاتفيًا. عمدًا لا نطلب رقم البطاقة الكامل ولا CVV هنا: فقط آخر 4
/// أرقام (لغرض المرجع على الإيصال لاحقًا) وتاريخ الانتهاء — فلا يمر أي رقم
/// بطاقة كامل عبر هذا التطبيق مطلقًا، بغض النظر عن طريقة الدفع المُستخدَمة.
/// (الدفع الإلكتروني المباشر بالبطاقة يمر عبر PaymentSheet من Stripe نفسها،
/// في StripeCardGateway — واجهة تلك الشاشة مملوكة لـ Stripe ولا يمكن إعادة
/// تصميمها من هذا التطبيق).
///
/// تُعيد هذه الشاشة عند التأكيد نصًا بالشكل last4|MM/YY|code عبر
/// Navigator.pop، ليتحقق منه ManualApprovalGateway قبل تسجيل البيع.
class ManualApprovalScreen extends StatefulWidget {
  final double amount;
  const ManualApprovalScreen({super.key, required this.amount});

  @override
  State<ManualApprovalScreen> createState() => _ManualApprovalScreenState();
}

class _ManualApprovalScreenState extends State<ManualApprovalScreen> {
  final _last4Controller = TextEditingController();
  final _expiryController = TextEditingController();
  final _codeController = TextEditingController();

  static final _last4Pattern = RegExp(r'^\d{4}$');
  static final _expiryPattern = RegExp(r'^(0[1-9]|1[0-2])/\d{2}$');
  static final _codePattern = RegExp(r'^\d{6}$');

  bool get _isValid =>
      _last4Pattern.hasMatch(_last4Controller.text) &&
      _expiryPattern.hasMatch(_expiryController.text) &&
      _codePattern.hasMatch(_codeController.text);

  @override
  void initState() {
    super.initState();
    for (final c in [_last4Controller, _expiryController, _codeController]) {
      c.addListener(_onFieldChanged);
    }
  }

  void _onFieldChanged() => setState(() {});

  @override
  void dispose() {
    for (final c in [_last4Controller, _expiryController, _codeController]) {
      c.removeListener(_onFieldChanged);
      c.dispose();
    }
    super.dispose();
  }

  void _submit() {
    if (!_isValid) return;
    final note = '${_last4Controller.text}|${_expiryController.text}|${_codeController.text}';
    Navigator.of(context).pop(note);
  }

  @override
  Widget build(BuildContext context) {
    final formatter = NumberFormat.currency(locale: 'en', name: AppConfig.currencyCode, decimalDigits: 2);

    return Scaffold(
      backgroundColor: AppColors.darkBackground,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  // BackButton (وليس أيقونة يدوية) لأنها تتكيّف تلقائيًا مع
                  // اتجاه الواجهة (RTL هنا) — أيقونة عادية لا تنعكس اتجاهها.
                  const BackButton(color: AppColors.darkTextPrimary),
                  const Expanded(
                    child: Text(
                      'إدخال يدوي للبطاقة',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: AppColors.darkTextPrimary, fontWeight: FontWeight.w800, fontSize: 17),
                    ),
                  ),
                  const SizedBox(width: 48),
                ],
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: AppColors.darkSurface,
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppColors.glow.withOpacity(0.35)),
                  boxShadow: [
                    BoxShadow(color: AppColors.glow.withOpacity(0.18), blurRadius: 24, offset: const Offset(0, 8)),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                          decoration: BoxDecoration(
                            color: AppColors.glow.withOpacity(0.15),
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Container(
                                width: 7,
                                height: 7,
                                decoration: const BoxDecoration(color: AppColors.glow, shape: BoxShape.circle),
                              ),
                              const SizedBox(width: 6),
                              const Text(
                                'تفويض هاتفي',
                                style: TextStyle(color: AppColors.glow, fontSize: 11, fontWeight: FontWeight.w700),
                              ),
                            ],
                          ),
                        ),
                        const Icon(Icons.credit_card, color: AppColors.darkTextSecondary),
                      ],
                    ),
                    const SizedBox(height: 18),
                    const Text('المبلغ الإجمالي', style: TextStyle(color: AppColors.darkTextSecondary, fontSize: 12)),
                    const SizedBox(height: 4),
                    Text(
                      formatter.format(widget.amount),
                      style: const TextStyle(color: AppColors.darkTextPrimary, fontSize: 30, fontWeight: FontWeight.w800),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              const Text(
                'اتصل بخط التفويض الصوتي للبنك، أملِ عليه بيانات البطاقة والمبلغ، ثم '
                'أدخل هنا آخر 4 أرقام من البطاقة وتاريخ الانتهاء ورمز الموافقة الذي يُملى عليك.',
                style: TextStyle(color: AppColors.darkTextSecondary, fontSize: 12.5, height: 1.5),
              ),
              const SizedBox(height: 18),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Expanded(
                    flex: 3,
                    child: _DarkField(
                      controller: _last4Controller,
                      label: 'آخر 4 أرقام من البطاقة',
                      maxLength: 4,
                      hint: '••••',
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: _DarkField(
                      controller: _expiryController,
                      label: 'الانتهاء MM/YY',
                      maxLength: 5,
                      hint: '10/30',
                      inputFormatters: [_ExpiryInputFormatter()],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              _DarkField(
                controller: _codeController,
                label: 'رمز الموافقة (6 أرقام)',
                maxLength: 6,
                hint: '••••••',
                letterSpacing: 4,
              ),
              const SizedBox(height: 24),
              FilledButton(
                onPressed: _isValid ? _submit : null,
                style: FilledButton.styleFrom(
                  backgroundColor: AppColors.glow,
                  foregroundColor: AppColors.darkBackground,
                  disabledBackgroundColor: AppColors.darkSurfaceAlt,
                  disabledForegroundColor: AppColors.darkTextSecondary,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                ),
                child: const Text('تأكيد وتسجيل البيع', style: TextStyle(fontWeight: FontWeight.w800)),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _DarkField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final int maxLength;
  final String hint;
  final double? letterSpacing;
  final List<TextInputFormatter>? inputFormatters;

  const _DarkField({
    required this.controller,
    required this.label,
    required this.maxLength,
    required this.hint,
    this.letterSpacing,
    this.inputFormatters,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: const TextStyle(color: AppColors.darkTextSecondary, fontSize: 12, fontWeight: FontWeight.w600)),
        const SizedBox(height: 6),
        TextField(
          controller: controller,
          keyboardType: TextInputType.number,
          textDirection: TextDirection.ltr,
          textAlign: TextAlign.center,
          maxLength: maxLength,
          inputFormatters: inputFormatters ?? [FilteringTextInputFormatter.digitsOnly],
          style: TextStyle(
            color: AppColors.darkTextPrimary,
            fontSize: 18,
            fontWeight: FontWeight.w700,
            letterSpacing: letterSpacing,
          ),
          decoration: InputDecoration(
            counterText: '',
            hintText: hint,
            hintStyle: const TextStyle(color: AppColors.darkTextSecondary),
            filled: true,
            fillColor: AppColors.darkSurfaceAlt,
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(12), borderSide: BorderSide.none),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12),
              borderSide: const BorderSide(color: AppColors.glow, width: 1.6),
            ),
          ),
        ),
      ],
    );
  }
}

/// يُنسّق الإدخال تلقائيًا إلى MM/YY أثناء الكتابة (بدون حزمة خارجية).
class _ExpiryInputFormatter extends TextInputFormatter {
  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    final digitsOnly = newValue.text.replaceAll(RegExp(r'[^0-9]'), '');
    final limited = digitsOnly.length > 4 ? digitsOnly.substring(0, 4) : digitsOnly;
    final formatted = limited.length <= 2 ? limited : '${limited.substring(0, 2)}/${limited.substring(2)}';
    return TextEditingValue(
      text: formatted,
      selection: TextSelection.collapsed(offset: formatted.length),
    );
  }
}
