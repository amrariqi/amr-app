// النماذج الأساسية: المنتج، طريقة الدفع، عنصر الفاتورة، والفاتورة (البيعة).
//
// ملاحظة مهمة ومقصودة: لا يوجد هنا أي حقل لرقم بطاقة أو تاريخ انتهاء أو CVV،
// ولن يُضاف أبدًا. بيانات البطاقة تُجمع فقط عبر SDK بوابة الدفع المرخّصة نفسها،
// ولا تصل إلى قاعدة بيانات هذا التطبيق مطلقًا — راجع services/payment_gateway.dart.

import '../utils/uuid.dart';

class Product {
  final int? id;
  final String name;
  final double price;
  final int stockQuantity;
  final String? category;
  final String? barcode;
  // يُنبَّه في شاشة المخزون والرئيسية عندما تصل الكمية المتوفرة لهذا الرقم
  // أو أقل — قابل للتخصيص لكل منتج (منتج سريع الدوران يحتاج عتبة أعلى من
  // منتج بطيء)، بدل رقم ثابت واحد يُطبَّق على كل المنتجات.
  final int lowStockThreshold;

  const Product({
    this.id,
    required this.name,
    required this.price,
    required this.stockQuantity,
    this.category,
    this.barcode,
    this.lowStockThreshold = 5,
  });

  Product copyWith({
    int? id,
    String? name,
    double? price,
    int? stockQuantity,
    String? category,
    String? barcode,
    int? lowStockThreshold,
  }) {
    return Product(
      id: id ?? this.id,
      name: name ?? this.name,
      price: price ?? this.price,
      stockQuantity: stockQuantity ?? this.stockQuantity,
      category: category ?? this.category,
      barcode: barcode ?? this.barcode,
      lowStockThreshold: lowStockThreshold ?? this.lowStockThreshold,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'price': price,
      'stock_quantity': stockQuantity,
      'category': category,
      'barcode': barcode,
      'low_stock_threshold': lowStockThreshold,
    };
  }

  factory Product.fromMap(Map<String, dynamic> map) {
    return Product(
      id: map['id'] as int?,
      name: map['name'] as String,
      price: (map['price'] as num).toDouble(),
      stockQuantity: map['stock_quantity'] as int,
      category: map['category'] as String?,
      barcode: map['barcode'] as String?,
      // صفوف قديمة أُنشئت قبل إضافة هذا العمود تحصل على القيمة الافتراضية
      // (5) عبر DEFAULT في ALTER TABLE نفسه، لكن هذا احتياط إضافي مطابق
      // لنفس النمط المُتَّبع مع clientUuid في Sale.fromMap أدناه.
      lowStockThreshold: (map['low_stock_threshold'] as int?) ?? 5,
    );
  }
}

// اسم مختلف عمدًا عن "PaymentMethod" — حزمة flutter_stripe (عبر
// stripe_platform_interface) تُصدِّر بنفسها نوعًا باسم PaymentMethod، وأي
// ملف يستورد الاثنين معًا يفشل بخطأ "imported from both" عند البناء.
//
// manualApproval: "موافقة هاتفية" (Voice/Manual Authorization) — يُستخدم
// حين يتصل البنك بحامل البطاقة مباشرة (شائع في الأماكن السياحية أو عند
// ضعف الاتصال) ويمنحه رمز موافقة يُملى على الكاشير هاتفيًا. هذه الطريقة
// منفصلة عمدًا عن "card": لا تمر عبر Stripe ولا يوجد أي تحقق إلكتروني من
// صحة الرمز أو أن المال تحرّك فعلًا — راجع ManualApprovalGateway في
// services/payment_gateway.dart للتفاصيل الكاملة لهذا التنبيه المهم.
enum POSPaymentMethod { cash, card, wallet, manualApproval }

extension POSPaymentMethodX on POSPaymentMethod {
  String get label {
    switch (this) {
      case POSPaymentMethod.cash:
        return 'نقدًا';
      case POSPaymentMethod.card:
        return 'بطاقة';
      case POSPaymentMethod.wallet:
        return 'محفظة إلكترونية';
      case POSPaymentMethod.manualApproval:
        return 'موافقة هاتفية';
    }
  }

  String get storageValue => name;

  static POSPaymentMethod fromStorage(String value) {
    return POSPaymentMethod.values.firstWhere(
      (e) => e.name == value,
      orElse: () => POSPaymentMethod.cash,
    );
  }
}

class SaleItem {
  final int? id;
  final int? saleId;
  final int productId;
  final String productName; // نسخة من اسم المنتج وقت البيع
  final double unitPrice;
  final int quantity;

  const SaleItem({
    this.id,
    this.saleId,
    required this.productId,
    required this.productName,
    required this.unitPrice,
    required this.quantity,
  });

  double get lineTotal => unitPrice * quantity;

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'sale_id': saleId,
      'product_id': productId,
      'product_name': productName,
      'unit_price': unitPrice,
      'quantity': quantity,
    };
  }

  factory SaleItem.fromMap(Map<String, dynamic> map) {
    return SaleItem(
      id: map['id'] as int?,
      saleId: map['sale_id'] as int?,
      productId: map['product_id'] as int,
      productName: map['product_name'] as String,
      unitPrice: (map['unit_price'] as num).toDouble(),
      quantity: map['quantity'] as int,
    );
  }
}

class Sale {
  final int? id;
  // معرّف ثابت (UUID) يُنشأ محليًا لحظة إتمام البيع، ويُستخدم كما هو عند
  // رفع نفس العملية إلى Supabase — راجع lib/services/sales_sync_service.dart.
  final String clientUuid;
  final DateTime createdAt;
  final double total;
  final POSPaymentMethod paymentMethod;
  final String? gatewayReference; // رقم مرجعي من بوابة الدفع فقط — أبدًا رقم بطاقة
  final bool synced;
  final List<SaleItem> items;

  const Sale({
    this.id,
    required this.clientUuid,
    required this.createdAt,
    required this.total,
    required this.paymentMethod,
    this.gatewayReference,
    this.synced = false,
    this.items = const [],
  });

  Sale copyWith({int? id, bool? synced}) {
    return Sale(
      id: id ?? this.id,
      clientUuid: clientUuid,
      createdAt: createdAt,
      total: total,
      paymentMethod: paymentMethod,
      gatewayReference: gatewayReference,
      synced: synced ?? this.synced,
      items: items,
    );
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'client_uuid': clientUuid,
      'created_at': createdAt.toIso8601String(),
      'total': total,
      'payment_method': paymentMethod.storageValue,
      'gateway_reference': gatewayReference,
      'synced': synced ? 1 : 0,
    };
  }

  factory Sale.fromMap(Map<String, dynamic> map, {List<SaleItem> items = const []}) {
    return Sale(
      id: map['id'] as int?,
      // صفوف قديمة أُنشئت قبل إضافة هذا العمود قد لا تملك قيمة — نولّد واحدة
      // بدلًا منها بدل الانهيار، رغم أنها لن تُخزَّن في تلك الصفوف تلقائيًا.
      clientUuid: (map['client_uuid'] as String?) ?? generateUuidV4(),
      createdAt: DateTime.parse(map['created_at'] as String),
      total: (map['total'] as num).toDouble(),
      paymentMethod: POSPaymentMethodX.fromStorage(map['payment_method'] as String),
      gatewayReference: map['gateway_reference'] as String?,
      synced: (map['synced'] as int) == 1,
      items: items,
    );
  }
}
