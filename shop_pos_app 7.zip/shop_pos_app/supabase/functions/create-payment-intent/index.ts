// Creates a Stripe PaymentIntent server-side, and (with a different request
// shape) looks up a completed PaymentIntent's charge to return a card
// approval/authorization reference for the receipt. The app only ever holds
// the Stripe *publishable* key; this is the one place the *secret* key is
// used, and it comes from an environment secret (STRIPE_SECRET_KEY) set on
// this Supabase project — never from a file in this repo.
//
// verify_jwt is OFF: this project's client uses the modern sb_publishable_
// key (not a legacy JWT anon key), which Supabase's built-in verify_jwt
// check does not accept. This function needs no real per-caller auth beyond
// that anyway — it matches the same open-MVP model as this project's RLS
// policies (see the init_pos_schema migration): the publishable key is
// trusted because this Supabase project is dedicated to this one app. It
// never touches or returns the Stripe secret key, so exposing it isn't a
// funds risk — at most, spam calls create unused test PaymentIntents or
// look up charges that belong to this same test account.
//
// Payment method coverage (honest state, checked directly against Stripe's
// and flutter_stripe's own docs/issue tracker before writing this — do not
// widen this note without re-checking, things here change fast):
//   - automatic_payment_methods (below) replaces a previous hardcoded
//     "card"-only list, so Stripe itself now decides which methods are
//     eligible for the request's currency/amount and this account's
//     Dashboard settings. Cards, Google Pay and Apple Pay (both tokenize as
//     "card" under the hood) keep working exactly as before — zero
//     regression risk.
//   - Alipay CAN work through this same PaymentIntent, but flutter_stripe's
//     PaymentSheet only actually surfaces it once the app ALSO configures a
//     `returnURL` (a custom URL scheme + an Android intent-filter). That is
//     a separate, carefully-tested client change — deliberately NOT bundled
//     into this pass: a wrong intent-filter risks breaking the app's launch
//     behavior entirely, and there is no way to compile-test that change
//     here first.
//   - WeChat Pay is confirmed UNSUPPORTED on mobile by Stripe itself (per
//     the flutter_stripe maintainers, in response to the exact same
//     question). No backend or client change here can add it — a real
//     WeChat Pay integration needs a different provider and WeChat's own
//     native SDK, entirely outside Stripe.

import 'jsr:@supabase/functions-js/edge-runtime.d.ts';

const STRIPE_SECRET_KEY = Deno.env.get('STRIPE_SECRET_KEY');

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' },
  });
}

Deno.serve(async (req: Request) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  if (!STRIPE_SECRET_KEY) {
    return json({ error: 'STRIPE_SECRET_KEY is not configured on this project yet.' }, 500);
  }

  let payload: any;
  try {
    payload = await req.json();
  } catch {
    return json({ error: 'Invalid JSON body.' }, 400);
  }

  // Existing behavior: create a new PaymentIntent for the sale screen's
  // "Charge card" step.
  if (payload.amountCents !== undefined) {
    const { amountCents, currency } = payload;

    if (!Number.isInteger(amountCents) || amountCents <= 0) {
      return json({ error: 'amountCents must be a positive integer.' }, 400);
    }

    const body = new URLSearchParams();
    body.set('amount', String(amountCents));
    body.set('currency', (currency || 'usd').toLowerCase());
    // Let Stripe pick eligible payment methods for this currency/amount +
    // this account's Dashboard settings, instead of hardcoding "card" only.
    // See the file-level comment above for exactly what this does and does
    // not unlock today.
    body.set('automatic_payment_methods[enabled]', 'true');

    const stripeRes = await fetch('https://api.stripe.com/v1/payment_intents', {
      method: 'POST',
      headers: {
        Authorization: 'Basic ' + btoa(`${STRIPE_SECRET_KEY}:`),
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body,
    });

    const data = await stripeRes.json();
    if (!stripeRes.ok) {
      return json({ error: data.error?.message ?? 'Stripe error' }, stripeRes.status);
    }

    return json({ clientSecret: data.client_secret, paymentIntentId: data.id });
  }

  // New behavior: after PaymentSheet confirms success, look up that
  // PaymentIntent's charge to get a real, bank-issued approval reference —
  // never something the app itself invents. Falls back to the charge ID
  // (always present) when the card network didn't return a distinct
  // authorization code, which is normal for many cards/networks and for
  // Stripe test mode.
  if (payload.paymentIntentId) {
    const piRes = await fetch(
      `https://api.stripe.com/v1/payment_intents/${encodeURIComponent(payload.paymentIntentId)}?expand[]=latest_charge`,
      { headers: { Authorization: 'Basic ' + btoa(`${STRIPE_SECRET_KEY}:`) } }
    );
    const pi = await piRes.json();
    if (!piRes.ok) {
      return json({ error: pi.error?.message ?? 'Stripe error' }, piRes.status);
    }
    if (pi.status !== 'succeeded') {
      return json({ error: 'Payment has not succeeded; no approval reference to return.' }, 409);
    }

    const charge = pi.latest_charge;
    const authCode: string | null = charge?.payment_method_details?.card?.authorization_code ?? null;
    const chargeId: string = charge?.id ?? pi.id;
    // Prefer the real network authorization code; otherwise fall back to a
    // short, readable slice of the (always-present) charge id. Either way
    // this value is entirely determined by Stripe/the card network, never
    // typed or chosen by the app or the cashier.
    const approvalCode = authCode || chargeId.replace(/^ch_/, '').slice(-8).toUpperCase();

    return json({
      chargeId,
      authorizationCode: authCode,
      approvalCode,
      cardBrand: charge?.payment_method_details?.card?.brand ?? null,
      last4: charge?.payment_method_details?.card?.last4 ?? null,
    });
  }

  return json({ error: 'Request must include either amountCents or paymentIntentId.' }, 400);
});
